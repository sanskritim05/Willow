"""Markdown report + figures (paper-ready drafts)."""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
INK, MUTED, GRID = "#0b0b0b", "#898781", "#e1e0d9"


def _style(ax, title):
    ax.set_title(title, loc="left", fontsize=11, color=INK)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#c3c2b7")
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.grid(color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)


def _pretty(name):
    return name.replace("_change", " + changes").replace("_status_only", " (status only)").replace("_", " ")


def figures(out_dir, calib, dca, fair, importance, primary):
    names = list(dict.fromkeys(calib.model))
    fig, ax = plt.subplots(figsize=(5, 4.2))
    mx = max(calib.mean_pred.max(), calib.obs_rate.max()) * 1.05
    ax.plot([0, mx], [0, mx], color=MUTED, lw=1, ls="--", label="perfect calibration")
    for i, m in enumerate(names):
        c = calib[calib.model == m]
        ax.plot(c.mean_pred, c.obs_rate, marker="o", ms=4, lw=2, color=SERIES[i], label=_pretty(m))
    ax.set_xlabel("Predicted risk", color=MUTED); ax.set_ylabel("Observed rate", color=MUTED)
    _style(ax, "Calibration (test set, deciles)"); ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_calibration.png"), dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.5, 4.2))
    base = dca[dca.model == names[0]]
    ax.plot(base.threshold, base.treat_all, color=MUTED, lw=1, ls="--", label="review everyone")
    ax.axhline(0, color="#c3c2b7", lw=1, label="review no one")
    for i, m in enumerate(names):
        d = dca[dca.model == m]
        ax.plot(d.threshold, d.net_benefit, lw=2, color=SERIES[i], label=_pretty(m))
    ax.set_ylim(-0.02, max(dca.net_benefit.max(), 0.02) * 1.15); ax.set_xlim(0.02, 0.4)
    ax.set_xlabel("Risk threshold for review", color=MUTED); ax.set_ylabel("Net benefit", color=MUTED)
    _style(ax, "Decision curve"); ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_decision_curve.png"), dpi=160); plt.close(fig)

    f = fair[(fair.model == primary) & fair.sensitivity.notna()] if "sensitivity" in fair else fair.iloc[0:0]
    if len(f):
        fig, ax = plt.subplots(figsize=(6, 0.28 * len(f) + 1))
        labels = [f"{r.subgroup} = {r.level}" for r in f.itertuples()]
        ax.barh(labels, f.sensitivity, color=SERIES[0], height=0.6)
        ax.invert_yaxis(); ax.set_xlim(0, 1); ax.set_xlabel("Sensitivity at alert threshold", color=MUTED)
        _style(ax, "Who gets missed? Sensitivity by subgroup (primary model)")
        fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_subgroup_sensitivity.png"), dpi=160); plt.close(fig)

    imp = importance[importance.direction == "worse"].head(12)
    fig, ax = plt.subplots(figsize=(6.4, 0.34 * len(imp) + 1.2))
    ax.barh(imp.group, imp.mean_contribution * 100, color=SERIES[0], height=0.6)
    ax.invert_yaxis(); ax.set_xlabel("Mean rise in predicted risk attributable to the decline (percentage points)",
                                     color=MUTED, fontsize=8)
    _style(ax, "Which declines move risk most")
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_change_importance.png"), dpi=160); plt.close(fig)


def write_report(out_dir, metrics, boot, fair, sens, importance, calib, dca, primary, source):
    figures(out_dir, calib, dca, fair, importance, primary)
    m = metrics.merge(boot, on="model", how="left")
    lines = [f"# Early Signals — results (NHATS)", ""]
    lines += ["## Discrimination, calibration, and alerting (held-out people, later rounds)", "",
              "| Model | AUROC (95% CI) | AUPRC | Brier | O/E | Cal. slope | Sensitivity | PPV | Alert rate |",
              "|---|---|---|---|---|---|---|---|---|"]
    for r in m.itertuples():
        lines.append(f"| {_pretty(r.model)} | {r.auroc:.3f} ({r.auroc_lo:.3f}–{r.auroc_hi:.3f}) | {r.auprc:.3f} | "
                     f"{r.brier:.3f} | {r.obs_exp:.2f} | {r.cal_slope:.2f} | {r.sensitivity:.2f} | {r.ppv:.2f} | "
                     f"{r.alert_rate:.2f} |")
    g = m.dropna(subset=["auroc_gain_vs_baseline"])
    lines += ["", "**AUROC gain over status-only logistic regression (paired, person-clustered bootstrap):**", ""]
    lines += [f"- {_pretty(r.model)}: +{r.auroc_gain_vs_baseline:.3f} ({r.gain_lo:.3f} to {r.gain_hi:.3f})"
              for r in g.itertuples()]
    lines += ["", "![calibration](fig_calibration.png)", "", "![decision curve](fig_decision_curve.png)", "",
              "## Subgroup audit (primary model)", "",
              "95% CIs from a person-clustered bootstrap within each group. O/E > 1 means the model "
              "UNDER-estimates risk for that group.", "",
              "| Subgroup | Level | n | Prev. | AUROC (95% CI) | O/E (95% CI) | Sensitivity (95% CI) | FPR | Alert rate |",
              "|---|---|---|---|---|---|---|---|---|"]
    ci = lambda v, lo, hi, f: f"{v:{f}} ({lo:{f}}–{hi:{f}})" if lo == lo else f"{v:{f}}"
    for r in fair[fair.model == primary].itertuples():
        if hasattr(r, "auroc") and r.auroc == r.auroc:
            lines.append(f"| {r.subgroup} | {r.level} | {r.n} | {r.prevalence:.3f} | "
                         f"{ci(r.auroc, r.auroc_lo, r.auroc_hi, '.3f')} | {ci(r.obs_exp, r.obs_exp_lo, r.obs_exp_hi, '.2f')} | "
                         f"{ci(r.sensitivity, r.sensitivity_lo, r.sensitivity_hi, '.2f')} | {r.fpr:.2f} | {r.alert_rate:.2f} |")
        else:
            lines.append(f"| {r.subgroup} | {r.level} | {r.n} | — | too few events to report | | | | |")
    lines += ["", "![subgroups](fig_subgroup_sensitivity.png)", "", "## Which changes drive risk", "",
              "Direction-aware. For people whose situation got **worse** in an area between t-1 and t: average "
              "rise in predicted risk attributable to that decline (estimate minus estimate had the decline not "
              "happened), and the observed rate of new help at t+1.", "",
              "| Change | Direction | People | Mean contribution (pts) | Share where it raised risk | Observed new help |",
              "|---|---|---|---|---|---|"]
    for r in importance.itertuples():
        mc = "—" if r.mean_contribution != r.mean_contribution else f"{r.mean_contribution * 100:+.1f}"
        sh = "—" if r.share_raised_risk != r.share_raised_risk else f"{r.share_raised_risk:.0%}"
        ob = f"{r.observed_new_help:.1%}" if hasattr(r, "observed_new_help") else ""
        lines.append(f"| {r.group} | {r.direction} | {r.n:,} | {mc} | {sh} | {ob} |")
    lines += ["", "![changes](fig_change_importance.png)", "", "## Sensitivity analyses (primary model)", "",
              "| Outcome | n | Prevalence | AUROC | AUPRC |", "|---|---|---|---|---|"]
    for r in sens.itertuples():
        lines.append(f"| {r.outcome} | {r.n:,} | {r.prevalence:.3f} | {r.auroc:.3f} | {r.auprc:.3f} |")
    with open(os.path.join(out_dir, "report.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
