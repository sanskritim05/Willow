"""CLI:  python -m early_signals run --nhats-dir /path/to/NHATS
        python -m early_signals inspect --nhats-dir /path/to/NHATS"""
import argparse
import os


def main():
    ap = argparse.ArgumentParser(prog="early_signals")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run the full pipeline")
    r.add_argument("--nhats-dir", required=True, help="folder with the NHATS Round 1-14 SP files")
    r.add_argument("--out", default="outputs")
    r.add_argument("--outcome", default="y_any", choices=["y_any", "y_mobility", "y_selfcare", "y_composite"])
    r.add_argument("--split-round", type=int)
    r.add_argument("--bootstrap", type=int, default=200)
    r.add_argument("--no-expanded", action="store_true", help="skip the expanded/tuned secondary model")
    r.add_argument("--tune-configs", type=int, default=12, help="tree hyperparameter configs per feature set")
    r.add_argument("--repeats", type=int, default=10, help="re-drawn test splits for robustness")
    d = sub.add_parser("describe", help="aggregate sanity-check tables (safe to share)")
    d.add_argument("--nhats-dir", required=True)
    dc = sub.add_parser("dementia-check", help="compare dementia classification with NHATS published counts")
    dc.add_argument("--nhats-dir", required=True)
    am = sub.add_parser("export-app-model", help="train the check-in app's model and write its coefficients (JSON)")
    am.add_argument("--nhats-dir", required=True)
    am.add_argument("--out", default="app_model.json")
    i = sub.add_parser("inspect", help="check the variable map against your NHATS files")
    i.add_argument("--nhats-dir", required=True)
    a = ap.parse_args()
    if a.cmd == "run":
        from .pipeline import run
        run(a.nhats_dir, a.out, a.outcome, a.split_round, bootstrap=a.bootstrap,
            expanded=not a.no_expanded, tune_configs=a.tune_configs, repeats=a.repeats)
    elif a.cmd == "dementia-check":
        from .dementia import check
        res = check(a.nhats_dir)
        print(res.to_string(index=False))
        known = res.dropna(subset=["match"])
        print(f"\n{int(known.match.sum())}/{len(known)} published counts matched exactly")
    elif a.cmd == "export-app-model":
        from .app_model import export
        export(a.nhats_dir, a.out)
    elif a.cmd == "describe":
        from .describe import describe  # pandas-only path: no scikit-learn needed
        from .nhats_loader import load_panel
        panel = load_panel(os.path.expanduser(a.nhats_dir))
        print(describe(panel))
    else:
        from .nhats_loader import inspect
        df = inspect(a.nhats_dir)
        miss = df[~df.found]
        print(df.groupby("round").found.mean().rename("share_found").to_string())
        print(f"\n{len(miss)} missing variable(s):")
        print(miss.to_string(index=False) if len(miss) else "none")


if __name__ == "__main__":
    main()
