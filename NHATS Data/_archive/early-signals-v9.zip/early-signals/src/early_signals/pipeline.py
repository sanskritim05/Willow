"""End-to-end run: data -> windows -> models -> evaluation -> fairness -> explanations -> outputs."""
from __future__ import annotations

import json
import os

import numpy as np
import pandas as pd

from . import evaluate as ev
from .explain import change_contributions, global_change_importance, shap_summary
from .features import build_windows, make_X
from .models import model_specs
from .schema import (ACTIVITIES, CHANGE_GROUPS, DEVICE_ACTS, HELP_COLS, LESS_ACTS, SUBGROUP_COLS,
                     TRACKED_ITEMS)

ALERT_RATE = 0.20  # flag the top 20% of predicted risk (threshold fixed on TRAINING data)


def load(nhats_dir: str) -> pd.DataFrame:
    """Load the NHATS public-use SP files (Rounds 1-14) into the long panel. NHATS is the only data source."""
    from .nhats_loader import load_panel
    if not nhats_dir:
        raise SystemExit("--nhats-dir is required (the folder with your NHATS Round 1-14 SP files)")
    return load_panel(os.path.expanduser(nhats_dir))


def run(nhats_dir=None, out_dir="outputs", outcome="y_any", split_round=None, seed=0, bootstrap=200,
        verbose=True, expanded=True, tune_configs=12, repeats=10, panel=None):
    """Full analysis on NHATS. `panel` lets the unit tests pass a small fake panel; real runs leave it None."""
    log = print if verbose else (lambda *a, **k: None)
    os.makedirs(out_dir, exist_ok=True)
    source = "nhats" if panel is None else "test_fixture"
    if panel is None:
        panel = load(nhats_dir)
    windows = build_windows(panel)
    analytic = windows[windows[outcome].notna()].copy()
    analytic[outcome] = analytic[outcome].astype(int)
    if split_round is None:
        split_round = int(analytic["round"].max()) - 3
    train, test = ev.temporal_person_split(analytic, split_round, seed=seed)
    log(f"[data] {panel.person_id.nunique():,} people, {len(analytic):,} at-risk windows; "
        f"train {len(train):,} (outcome round <= {split_round}), test {len(test):,} (t >= {split_round}, new people)")

    fitted, preds, rows, thresholds = {}, {}, [], {}
    for name, (fset, factory) in model_specs().items():
        m = factory()
        Xtr, Xte = make_X(train, fset), make_X(test, fset)
        m.fit(Xtr, train[outcome].values)
        p_tr = m.predict_proba(Xtr)[:, 1]
        p = m.predict_proba(Xte)[:, 1]
        thr = float(np.quantile(p_tr, 1 - ALERT_RATE))
        r = {"model": name, "features": fset}
        r.update(ev.core_metrics(test[outcome].values, p))
        r.update({f"weighted_{k}": v for k, v in ev.core_metrics(test[outcome].values, p, test["weight"].values).items()
                  if k in ("auroc", "auprc", "prevalence")})
        r.update(ev.threshold_metrics(test[outcome].values, p, thr))
        rows.append(r)
        fitted[name], preds[name], thresholds[name] = (m, fset), p, thr
        log(f"[model] {name:32s} AUROC {r['auroc']:.3f}  AUPRC {r['auprc']:.3f}  O/E {r['obs_exp']:.2f}  "
            f"slope {r['cal_slope']:.2f}  sens@{ALERT_RATE:.0%} {r['sensitivity']:.2f}")
    metrics = pd.DataFrame(rows)
    names = list(preds)
    primary = names[-1]  # pre-specified primary model: gradient boosting with change features

    boot = ev.cluster_bootstrap(test, preds, outcome, B=bootstrap, seed=seed)
    calib = pd.concat([ev.calibration_bins(test[outcome].values, preds[k]).assign(model=k) for k in names])
    dca = pd.concat([ev.decision_curve(test[outcome].values, preds[k]).assign(model=k) for k in names])
    fair = pd.concat([ev.subgroup_audit(test, preds[k], outcome, thresholds[k], SUBGROUP_COLS).assign(model=k)
                      for k in (names[1], primary)])

    # sensitivity analyses: separate outcomes + composite (help OR care move OR death)
    sens_rows = []
    for alt in ["y_mobility", "y_selfcare", "y_composite"]:
        a = windows[windows[alt].notna()]
        tr, te = ev.temporal_person_split(a, split_round, seed=seed)
        m, fset = model_specs()[primary][1](), model_specs()[primary][0]
        m.fit(make_X(tr, fset), tr[alt].astype(int).values)
        pa = m.predict_proba(make_X(te, fset))[:, 1]
        sens_rows.append({"outcome": alt, **ev.core_metrics(te[alt].astype(int).values, pa)})
    # pandemic sensitivity: drop every window touching 2020/2021 (rounds 9-11 as t), train + test again
    nc = analytic[(analytic.covid_change == 0) & (analytic.covid_outcome == 0)]
    tr, te = ev.temporal_person_split(nc, split_round, seed=seed)
    if len(te) and te[outcome].nunique() == 2:
        m, fset = model_specs()[primary][1](), model_specs()[primary][0]
        m.fit(make_X(tr, fset), tr[outcome].values)
        sens_rows.append({"outcome": f"{outcome} (excluding pandemic windows)",
                          **ev.core_metrics(te[outcome].values, m.predict_proba(make_X(te, fset))[:, 1])})
    # post-pandemic test windows only (outcome in 2022 or later), primary model as trained above
    post = (test["round"] + 1 >= 12).values
    if post.sum() and test[outcome].values[post].sum():
        sens_rows.append({"outcome": f"{outcome} (test outcomes 2022+ only)",
                          **ev.core_metrics(test[outcome].values[post], preds[primary][post])})
    sens = pd.DataFrame(sens_rows)

    # explanations
    model, fset = fitted[primary]
    contrib = change_contributions(model, fset, test.reset_index(drop=True))
    importance = global_change_importance(contrib, test.reset_index(drop=True)[outcome].values)
    shap_df = shap_summary(model, make_X(test, fset))

    for nm, df in {"metrics": metrics, "bootstrap_ci": boot, "calibration": calib, "decision_curve": dca,
                   "subgroups": fair, "sensitivity_outcomes": sens, "change_importance": importance}.items():
        df.to_csv(os.path.join(out_dir, f"{nm}.csv"), index=False)
    if shap_df is not None:
        shap_df.to_csv(os.path.join(out_dir, "shap_importance.csv"), index=False)

    card = model_card(source, metrics, boot, fair[fair.model == primary], calib, dca, importance, sens,
                      primary, thresholds[primary], split_round, len(train), len(test))
    with open(os.path.join(out_dir, "model_card.json"), "w") as f:
        json.dump(card, f, indent=1, default=float)

    log("[privacy] aggregate outputs only; no individual NHATS records are written (NHATS conditions of use)")

    if expanded:
        from .tuning import run_expanded
        log("[expanded] tuning on training data only (5-fold person-grouped CV); test set used once")
        run_expanded(analytic, train, test, outcome, out_dir, preds, split_round, primary,
                     n_trees_configs=tune_configs, repeats=repeats, seed=seed, log=log, panel=panel, windows=windows)
        log(f"[report] {os.path.join(out_dir, 'report_expanded.md')}")

    try:
        from .report import write_report
        write_report(out_dir, metrics, boot, fair, sens, importance, calib, dca, primary, source)
        log(f"[report] {os.path.join(out_dir, 'report.md')}")
    except Exception as e:  # plotting is optional
        log(f"[report] skipped figures: {e}")
    return {"metrics": metrics, "bootstrap": boot, "fairness": fair, "importance": importance, "primary": primary}


def _clean(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    return float(v) if isinstance(v, (np.floating, float)) else (int(v) if isinstance(v, (np.integer,)) else v)


def model_card(source, metrics, boot, fair, calib, dca, importance, sens, primary, thr, split_round, n_train, n_test):
    rec = lambda df: [{k: _clean(v) for k, v in r.items()} for r in df.to_dict("records")]
    return {
        "data_source": source,
        "primary_model": primary,
        "alert_rule": f"flag top {ALERT_RATE:.0%} of predicted risk (threshold {thr:.3f}, fixed on training data)",
        "threshold": thr,
        "split": {"split_round": split_round, "n_train_windows": n_train, "n_test_windows": n_test,
                  "design": "person-disjoint + time-ordered"},
        "metrics": rec(metrics), "bootstrap_ci": rec(boot), "subgroups": rec(fair),
        "calibration": rec(calib), "decision_curve": rec(dca[dca.model.isin([primary, metrics.model.iloc[0]])]),
        "change_importance": rec(importance), "sensitivity_outcomes": rec(sens),
        "intended_use": "Flags people whose recent changes in everyday activities suggest a higher chance of "
                        "needing help within a year, so a professional can review. Not a diagnosis of disability, "
                        "not a treatment recommendation, not for use without professional judgment.",
    }
