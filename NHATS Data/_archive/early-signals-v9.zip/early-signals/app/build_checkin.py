"""Build the Steady check-in app (app/index.html).

  python app/build_checkin.py --model app_model.json   # embed the NHATS-trained app model (required)

app_model.json comes from `python -m early_signals export-app-model --nhats-dir ...` and holds
aggregate model coefficients only.
"""
import argparse
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

ap = argparse.ArgumentParser()
ap.add_argument("--model", required=True, help="app_model.json from export-app-model (NHATS-trained)")
a = ap.parse_args()
html = open(os.path.join(HERE, "checkin.html")).read()
m = json.load(open(a.model))
if m.get("source") != "nhats":
    raise SystemExit("app_model.json must come from `python -m early_signals export-app-model --nhats-dir ...`.")
html = html.replace("/*APP_MODEL*/null", json.dumps(m, separators=(",", ":")))
open(os.path.join(HERE, "index.html"), "w").write(html)
print("wrote app/index.html (NHATS-trained model)")
