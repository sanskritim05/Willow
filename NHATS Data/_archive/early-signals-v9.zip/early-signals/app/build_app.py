"""Build app/research.html (aggregate results dashboard) from an NHATS run.

Usage: python app/build_app.py results_final
Embeds only model_card.json: aggregate metrics, calibration, and subgroup results. No individual
NHATS records are ever embedded (NHATS conditions of use).
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def _round(o):
    if isinstance(o, float):
        return round(o, 4)
    if isinstance(o, dict):
        return {k: _round(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_round(v) for v in o]
    return o


def main(out_dir="outputs"):
    card = json.load(open(os.path.join(out_dir, "model_card.json")))
    if card.get("data_source") != "nhats":
        sys.exit("model_card.json is not from an NHATS run; run `python -m early_signals run --nhats-dir ...` first.")
    tpl = open(os.path.join(HERE, "template.html")).read()
    html = tpl.replace("/*CARD*/{}", json.dumps(_round(card), separators=(",", ":")))
    dest = os.path.join(HERE, "research.html")
    open(dest, "w").write(html)
    print(f"wrote {dest} ({len(html) / 1024:.0f} KB, aggregate results only)")


if __name__ == "__main__":
    main(*sys.argv[1:])
