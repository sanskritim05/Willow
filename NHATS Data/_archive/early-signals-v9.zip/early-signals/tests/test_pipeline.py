import numpy as np
import pandas as pd
import pytest

from early_signals import evaluate as ev
from early_signals.features import build_windows, counterfactual, make_X
from early_signals.nhats_loader import _recode
from early_signals.schema import HELP_COLS
from fake_panel import generate  # test-only fixture; the analysis uses NHATS


@pytest.fixture(scope="module")
def panel():
    return generate(seed=1, scale=0.15)


@pytest.fixture(scope="module")
def windows(panel):
    return build_windows(panel)


def test_at_risk_means_no_help_at_t(windows):
    assert (windows[[f"{h}__cur" for h in HELP_COLS]].sum(axis=1) == 0).all()
    assert (windows["status__cur"] == "community").all() and (windows["status__prev"] == "community").all()


def test_no_future_information_in_features(windows):
    for fs in ("status", "change"):
        X = make_X(windows, fs)
        assert not any("next" in c or c.startswith("y_") for c in X.columns)


def test_features_do_not_change_when_future_changes(windows):
    """Scrambling round t+1 outcomes must leave features identical (leakage guard)."""
    w2 = windows.copy()
    w2["y_any"] = 1 - w2["y_any"].fillna(0)
    pd.testing.assert_frame_equal(make_X(windows), make_X(w2))


def test_outcome_matches_panel(panel, windows):
    row = windows[windows.y_any.notna()].iloc[0]
    nxt = panel[(panel.person_id == row.person_id) & (panel["round"] == row["round"] + 1)].iloc[0]
    assert int(row.y_any) == int(nxt[HELP_COLS].sum() > 0)


def test_split_is_person_disjoint_and_time_ordered(windows):
    a = windows[windows.y_any.notna()]
    tr, te = ev.temporal_person_split(a, split_round=10)
    assert set(tr.person_id).isdisjoint(te.person_id)
    assert (tr["round"] + 1).max() <= 10 and te["round"].min() >= 10


def test_counterfactual_removes_change(windows):
    cf = counterfactual(windows.head(50), ["go_out_freq"])
    assert (make_X(cf)["d_go_out_freq"].fillna(0) == 0).all()


def test_recode_handles_nhats_missing_codes():
    s = pd.Series([1, 2, -1, -7, -8, -9])
    out = _recode(s, {1: 1, 2: 0, -1: 0})
    assert out.tolist()[:3] == [1, 0, 0] and out.iloc[3:].isna().all()
    out = _recode(pd.Series([1, 2, 3, -9]), {1: 1, "_default": 0})
    assert out.tolist()[:3] == [1, 0, 0] and np.isnan(out.iloc[3])


def test_pipeline_runs_end_to_end(tmp_path):
    from early_signals.pipeline import run
    res = run(out_dir=str(tmp_path), bootstrap=10, verbose=False, expanded=False,
              panel=generate(seed=2, scale=0.2))
    assert res["metrics"]["auroc"].between(0.5, 1).all()
    assert (tmp_path / "model_card.json").exists()
    assert not (tmp_path / "personas.json").exists()  # no individual-level output, ever
