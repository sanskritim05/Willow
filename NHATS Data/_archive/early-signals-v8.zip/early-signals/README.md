# Early Signals

Can recent **changes** in how an older adult manages everyday life (going out less, starting to use a grab bar, going without a bath, new difficulty dressing) predict that they will **newly need help from another person** with mobility or self-care **one year later**? And can we show caregivers and clinicians *which* changes drove the estimate?

This repo holds both the research pipeline (for the paper) and the demo app. It runs end to end on **synthetic** NHATS-shaped data today. You switch to real NHATS by pointing it at your downloaded files.

```
config/variables.yaml        NHATS variable map (MUST be verified — see step 3)
src/early_signals/
  synth.py                   synthetic panel (no real people)
  nhats_loader.py            real NHATS round files -> canonical long panel
  features.py                prediction windows (t-1 -> t -> t+1), status + change features, outcomes
  models.py                  status-only logistic (baseline), logistic, random forest, XGBoost/HistGB
  evaluate.py                person-disjoint temporal split, AUROC/AUPRC/Brier, calibration, decision curves,
                             person-clustered bootstrap, subgroup audit
  explain.py                 counterfactual change attributions (+ SHAP if installed)
  pipeline.py, report.py     orchestration, CSVs, figures, report.md, model_card.json, personas.json
app/template.html, build_app.py   the demo app (embeds synthetic personas + model card)
tests/test_pipeline.py       leakage guards, split checks, loader recodes, end-to-end smoke test
```

## 1. Quick start (synthetic data)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[full,dev]"          # xgboost + shap optional; falls back to scikit-learn
python -m early_signals run --source synthetic --out outputs
python app/build_app.py outputs       # -> app/index.html, open in a browser
pytest -q
```

## 2. Get NHATS

1. Register at **https://www.nhats.org/data-access** and accept the conditions of use.
2. Download the **public-use Sample Person (SP) files and tracker files** for every round (Stata `.dta` is easiest). Put them in one folder, e.g. `~/data/nhats/`.
3. Download the NHATS **dementia classification** program, run it, and save a `demclas{r}` column per round, or edit `derived.dementia` in the config.
4. You don't need the sensitive or restricted files to start. Apply later if you want finer geography or linked Medicare claims.

> **Data rules that shape this project:** NHATS conditions of use forbid trying to identify anyone, sharing the data beyond your team, and **uploading it to public AI tools (Claude, ChatGPT, Gemini, etc.)**. They also require reporting only aggregate results. So:
> - run the pipeline on your own machine;
> - share only aggregate outputs (the CSVs, `report.md`, `model_card.json`, figures);
> - never build the public app from real people. `build_app.py` refuses to embed personas from non-synthetic data.
> - report your publications to NHATS as the terms require.

## 3. Verify the variable map (important)

`config/variables.yaml` maps NHATS variables to the pipeline's names. The **names and codes are my best templates and have not been verified.** Check every one against the NHATS codebooks and the Cross-Year Search, then set `verified: true`.

```bash
python -m early_signals inspect --nhats-dir ~/data/nhats   # lists mapped variables missing from your files
```

Things to check in particular:

- The skip patterns behind "help" and "difficulty". NHATS code `-1` (inapplicable) currently maps to "no".
- Device items: which devices count for each activity.
- The "going without / staying in" items.
- Residence codes, used for exits: residential care, nursing home, death.
- Proxy indicator, weights, strata and PSUs.

## 4. Run on NHATS

```bash
python -m early_signals run --source nhats --nhats-dir ~/data/nhats --out results_nhats
python -m early_signals run --source nhats --nhats-dir ~/data/nhats --out results_mob --outcome y_mobility
```

## Expanded model (secondary analysis)

`run` also builds a tuned **expanded** model unless you pass `--no-expanded`:
- extra measures: household activities (difficulty, and help because of health), self-reported physical
  capacity, measured walking speed / chair stands / grip / balance (not collected in 2020), symptoms,
  weight loss, BMI, chronic conditions, vision/hearing, social network size, Medicaid;
- two-year trends (t-2 -> t-1 -> t);
- selection by 5-fold person-grouped CV on training windows only (logistic, gradient-boosted trees, their
  average), Platt recalibration on out-of-fold predictions, one use of the locked test set;
- 10 re-drawn test splits for robustness, pooled race/ethnicity calibration gap, SHAP summary.
Outputs: `report_expanded.md`, `expanded_*.csv`, `repeated_splits.csv`. Faster run: `--tune-configs 6 --repeats 5`.

## Study design (as implemented)

| Piece | Choice |
|---|---|
| Unit | person-round window: history t-1 → t, outcome t+1 |
| At risk | living in the community at t-1 and t, **no help from a person with any of 7 activities at t** |
| Primary outcome | help from another person with going outside, moving inside, getting out of bed, eating, bathing, toileting or dressing at t+1 (among those still in the community) |
| Secondary | mobility-only, self-care-only; **composite** (help OR moved to care OR died) for competing exits |
| Features | status at t, change t-1→t (ordinal deltas, new-onset flags, counts), help at t-1, demographics; race/ethnicity is **not** a predictor, only an audit variable |
| Models | status-only logistic (reference), logistic + changes, random forest, XGBoost (or HistGradientBoosting) |
| Validation | **person-disjoint AND time-ordered**: train on outcome rounds ≤ split, test on held-out people at later rounds |
| Metrics | AUROC, AUPRC, Brier, observed/expected, calibration slope, sensitivity/PPV at a top-20% alert rule fixed on training data, decision curves, person-clustered bootstrap CIs, paired AUROC gain vs baseline |
| Fairness | the above by race/ethnicity, sex, income, living alone, proxy response, dementia status, age 85+ |
| Explanations | counterfactual: "estimate if this change hadn't happened", aggregated for the paper, per-person in the app |

**Not yet done:** design-based variance using NHATS strata and PSUs (currently a person-clustered bootstrap); multiple imputation (currently median imputation plus missing indicators); hyperparameter tuning with grouped cross-validation; recalibration. See the roadmap.

> **About the synthetic results:** the synthetic generator *builds in* a disablement process and two disparities: proxy under-reporting and less device access for low-income people. Any "finding" on synthetic data is there by construction. Only the NHATS run can tell you whether change features actually help.

## Paper roadmap

1. Verify the variable map; describe the cohort, including a flow diagram of exclusions and exits.
2. Main comparison: status-only vs change-aware models.
3. Calibration and decision curves.
4. Subgroup audit and error analysis: who gets missed, and why.
5. Sensitivity analyses:
   - composite outcome;
   - survey-weighted metrics;
   - excluding proxy interviews;
   - a split by cohort (2011 vs 2015 vs 2022).
6. Report with **TRIPOD+AI**. Targets: CHIL / MLHC / AMIA (short), then JAMIA, *JMIR Aging*, *J Gerontol* or *JAGS* (full).

## App roadmap

- Now: static demo with synthetic personas, which is what you show reviewers and investors.
- Next: a short caregiver/clinician check-in form covering the same ~20 items, so a real person can be scored without NHATS. A usability study with clinicians and caregivers could be its own paper.
- Keep the non-diagnostic framing and the model card. Get regulatory advice (FDA clinical decision support guidance) before any clinical use.
