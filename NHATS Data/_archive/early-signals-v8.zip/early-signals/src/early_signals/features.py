"""Turn the long panel into prediction windows and features.

A window is anchored at round t for one person:
    t-1  ->  t   : observed history (features: status at t + change since t-1)
    t+1          : outcome (new help from another person with mobility or self-care)

Only people living in the community and receiving NO help with any of the seven
activities at round t are "at risk". Nothing from round t+1 is ever used as a feature.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .schema import (BINARY_ITEMS_ALL, DEMOGRAPHICS, EXTRA_STATIC, HELP_COLS, HIGHER_IS_BETTER, MOBILITY,
                     NO_DIRECTION, ORDINAL_ITEMS_ALL, SELFCARE, STATUS_COMMUNITY, TRACKED_ITEMS, V1_BINARY,
                     V1_ITEMS, V1_ORDINAL)

OPTIONAL_DEMOGRAPHICS = ["low_income"]


def _any_help(df, acts=None):
    cols = HELP_COLS if acts is None else [f"{a}_help" for a in acts]
    return (df[cols].fillna(0).sum(axis=1) > 0).astype(int)


def build_windows(panel: pd.DataFrame) -> pd.DataFrame:
    """Return one row per eligible (person, t) with __prev / __cur item columns and outcomes."""
    p = panel.copy()
    for it in TRACKED_ITEMS + EXTRA_STATIC:   # older panels may lack the expanded measures
        if it not in p.columns:
            p[it] = np.nan
    keep = ["person_id", "round", "status"] + TRACKED_ITEMS + HELP_COLS
    extra = [c for c in DEMOGRAPHICS + OPTIONAL_DEMOGRAPHICS + EXTRA_STATIC +
             ["race_eth", "weight", "stratum", "psu", "cohort", "source"] if c in p.columns]
    cur = p[keep + [c for c in extra if c not in keep]].copy()
    prev = p[keep].copy()
    prev["round"] = prev["round"] + 1
    nxt = p[["person_id", "round", "status"] + HELP_COLS].copy()
    nxt["round"] = nxt["round"] - 1

    w = cur.merge(prev, on=["person_id", "round"], suffixes=("__cur", "__prev"))
    # two rounds back (optional; NaN when the person was not interviewed at home at t-2)
    prev2 = p[p.status == STATUS_COMMUNITY][["person_id", "round"] + TRACKED_ITEMS + HELP_COLS].copy()
    prev2["round"] = prev2["round"] + 2
    prev2 = prev2.rename(columns={c: f"{c}__prev2" for c in TRACKED_ITEMS + HELP_COLS})
    w = w.merge(prev2, on=["person_id", "round"], how="left")
    w = w.merge(nxt.rename(columns={c: f"{c}__next" for c in nxt.columns if c not in ("person_id", "round")}),
                on=["person_id", "round"], how="left")

    cur_help = w[[f"{h}__cur" for h in HELP_COLS]]
    eligible = (
        (w["status__cur"] == STATUS_COMMUNITY)
        & (w["status__prev"] == STATUS_COMMUNITY)
        & cur_help.notna().all(axis=1)
        & (cur_help.sum(axis=1) == 0)
        & w["status__next"].notna()
        & (w["status__next"] != "nonresponse")
    )
    w = w[eligible].copy()

    nxt_help = w[[f"{h}__next" for h in HELP_COLS]].rename(columns=lambda c: c.replace("__next", ""))
    in_comm = (w["status__next"] == STATUS_COMMUNITY)
    w["exit_next"] = w["status__next"]
    w["y_any"] = np.where(in_comm, _any_help(nxt_help), np.nan)
    w["y_mobility"] = np.where(in_comm, _any_help(nxt_help, MOBILITY), np.nan)
    w["y_selfcare"] = np.where(in_comm, _any_help(nxt_help, SELFCARE), np.nan)
    # composite for sensitivity analysis: new help OR moved to care OR died
    w["y_composite"] = np.where(in_comm, w["y_any"], 1.0)
    # calendar-period flags (known in advance, not leakage): NHATS round 10 = 2020, 11 = 2021
    w["covid_change"] = w["round"].isin([10, 11]).astype(int)     # t-1 -> t change spans the pandemic
    w["covid_outcome"] = w["round"].isin([9, 10]).astype(int)     # outcome year t+1 is 2020/2021
    w["prev_any_help"] = (w[[f"{h}__prev" for h in HELP_COLS]].fillna(0).sum(axis=1) > 0).astype(int)
    p2 = w[[f"{h}__prev2" for h in HELP_COLS]]
    w["prev2_any_help"] = np.where(p2.notna().any(axis=1), (p2.fillna(0).sum(axis=1) > 0).astype(float), np.nan)
    w = w.drop(columns=[f"{h}__prev2" for h in HELP_COLS])
    w = w.drop(columns=[c for c in w.columns if c.endswith("__next")])
    for c in ["age", "female", "lives_alone", "proxy", "low_income", "race_eth", "weight", "cohort", "source",
              "stratum", "psu"] + EXTRA_STATIC:
        if f"{c}__cur" in w.columns:
            w = w.rename(columns={f"{c}__cur": c})
        if f"{c}__prev" in w.columns and c != "proxy":
            w = w.drop(columns=f"{c}__prev")
    if "proxy__prev" in w.columns:
        w = w.drop(columns="proxy__prev")
    return w.reset_index(drop=True)


def _status_cols(w, items, static):
    c = {f"cur_{it}": w[f"{it}__cur"].values for it in items}
    for d in DEMOGRAPHICS + OPTIONAL_DEMOGRAPHICS + list(static):
        if d in w.columns:
            c[d] = w[d].values
    c["covid_change"] = w["covid_change"].values      # calendar flags go in every model, baseline included
    c["covid_outcome"] = w["covid_outcome"].values
    return c


def status_features(w: pd.DataFrame, items=None, static=()) -> pd.DataFrame:
    items = V1_ITEMS if items is None else items
    return pd.DataFrame(_status_cols(w, items, static), index=w.index)


def _worse(it, a, b):
    """Elementwise 'a is worse than b' respecting each item's direction."""
    if it in NO_DIRECTION:
        return np.zeros(len(a), dtype=bool)
    return (a < b) if it in HIGHER_IS_BETTER else (a > b)


def _new(c, p):
    v = ((c == 1) & (p == 0)).astype(float)
    v[np.isnan(c) | np.isnan(p)] = np.nan
    return v


def change_features(w: pd.DataFrame, ordinal=None, binary=None, static=(), two_year=False) -> pd.DataFrame:
    ordinal = list(V1_ORDINAL if ordinal is None else ordinal)
    binary = list(V1_BINARY if binary is None else binary)
    c = _status_cols(w, ordinal + binary, static)
    cur = {it: w[f"{it}__cur"].values.astype(float) for it in ordinal + binary}
    prv = {it: w[f"{it}__prev"].values.astype(float) for it in ordinal + binary}
    for it in ordinal:
        c[f"d_{it}"] = cur[it] - prv[it]
    for it in binary:
        c[f"new_{it}"] = _new(cur[it], prv[it])
    sumpos = lambda keys: np.nansum(np.vstack([c[k] for k in keys]), axis=0) if keys else np.zeros(len(w))
    c["n_worse_difficulty"] = sum((np.nan_to_num(c[k]) > 0).astype(int) for k in c if k.startswith("d_") and k.endswith("_diff"))
    c["n_new_devices"] = sumpos([k for k in c if k.startswith("new_") and k.endswith("_device")])
    c["n_new_doing_less"] = sumpos([k for k in c if k.startswith("new_") and k.endswith("_less")])
    c["n_new_went_without"] = sumpos([k for k in c if k.startswith("new_") and k.endswith("_wout")])
    c["prev_any_help"] = w["prev_any_help"].values
    if len(ordinal) > len(V1_ORDINAL):   # expanded sets: overall decline counts
        c["n_declines_now"] = sum(_worse(it, cur[it], prv[it]).astype(int) for it in ordinal + binary)
    if two_year:
        n_prev_int, n_sustained = 0, 0
        for it in ordinal + binary:
            p2 = w[f"{it}__prev2"].values.astype(float)
            if it in ordinal:
                c[f"d2_{it}"] = cur[it] - p2
            else:
                c[f"new2_{it}"] = _new(cur[it], p2)
            w_prev = _worse(it, prv[it], p2)
            n_prev_int = n_prev_int + w_prev.astype(int)
            n_sustained = n_sustained + (w_prev & _worse(it, cur[it], prv[it])).astype(int)
        c["n_declines_prev_year"] = n_prev_int
        c["n_sustained_declines"] = n_sustained
        c["has_t_minus_2"] = w[[f"{it}__prev2" for it in V1_ITEMS]].notna().any(axis=1).values.astype(float)
        c["prev2_any_help"] = w["prev2_any_help"].values
    return pd.DataFrame(c, index=w.index)


FEATURE_SETS = {
    # v1 (pre-specified)
    "status": lambda w: status_features(w),
    "change": lambda w: change_features(w),
    # expanded
    "status_plus": lambda w: status_features(w, ORDINAL_ITEMS_ALL + BINARY_ITEMS_ALL, EXTRA_STATIC),
    "change_plus": lambda w: change_features(w, ORDINAL_ITEMS_ALL, BINARY_ITEMS_ALL, EXTRA_STATIC),
    "change_plus_2yr": lambda w: change_features(w, ORDINAL_ITEMS_ALL, BINARY_ITEMS_ALL, EXTRA_STATIC, two_year=True),
}


def make_X(w: pd.DataFrame, feature_set: str = "change") -> pd.DataFrame:
    return FEATURE_SETS[feature_set](w).astype(float)


def counterfactual(w: pd.DataFrame, items: list[str]) -> pd.DataFrame:
    """Copy of windows where the given items did NOT change between t-1 and t."""
    cf = w.copy()
    for it in items:
        cf[f"{it}__cur"] = cf[f"{it}__prev"]
    return cf
