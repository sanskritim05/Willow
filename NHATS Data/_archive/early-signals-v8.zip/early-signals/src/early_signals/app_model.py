"""Train the model the check-in app runs, on NHATS, using ONLY what the app can ask.

The research models use survey items an app cannot collect (measured grip strength, the full
dementia battery, ...). This module maps NHATS items onto the app's check-in questions, fits a
penalized logistic regression (status + change), evaluates it on the same locked test design as
the paper, and writes a small JSON file of coefficients. The JSON holds aggregate model
parameters only (no respondent data) and is what `app/build_app.py --model` embeds in the app.

Mapping (app question -> NHATS item):
  area level 0-3 for 7 activities   <- device use / doing it less often (1), difficulty doing it
                                        alone (2), went without it (3)          [mo/sc derived + *yrgo + *wout]
  days out this week                <- how often goes outside (every day .. never)  [mo{r}outoft]
  fall or near fall recently         <- fell in the last month                     [hc{r}fllsinmth]
  low energy / pain limits           <- ss{r}lowenergy / ss{r}painlimts
  more trouble with memory           <- possible/probable dementia (NHATS classification)
  feeling down                       <- PHQ-2 >= 3
  household tasks hard / done by others for health  <- ha/mc derived self-difficulty and reason
  can't walk about 6 blocks          <- pc{r}walk6blks
  slow on 5 chair stands (>=15 s or unable)          <- ch{r}chstndsec / attempted-not-completed
  hospital stay, weight loss, age   <- hc{r}hosptstay, hw{r}lst10pnds, age group
Change features = value at t minus value at t-1. In the app, "t-1" is the person's baseline
(their check-ins 3-12 months earlier), so weekly/monthly use is an extrapolation of a model
trained on yearly change: to be validated prospectively.
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold

from . import evaluate as ev

AREAS = {"outside": "go_outside", "inside": "get_around_inside", "bed": "get_out_of_bed", "bathing": "bathing",
         "dressing": "dressing", "toilet": "toileting", "eating": "eating"}
TASKS = ["laundry", "shopping", "meals", "banking", "meds"]

LABELS = {
    "outside": "Going outside", "inside": "Moving around at home", "bed": "Getting out of bed",
    "bathing": "Bathing or showering", "dressing": "Getting dressed", "toilet": "Using the toilet",
    "eating": "Eating", "out": "Going out less often", "fall": "A recent fall", "energy": "Low energy",
    "pain": "Pain limiting activity", "memory": "More trouble with memory", "mood": "Feeling down",
    "iadl": "Household tasks getting harder", "walk": "Can't walk about 6 blocks",
    "chair": "Slower getting up from a chair", "hospital": "A hospital stay", "weight": "Weight loss",
    "age": "Age",
}


def _col(w, name, when):
    c = f"{name}__{when}"
    return w[c].astype(float).values if c in w.columns else np.full(len(w), np.nan)


def _level(w, act, when):
    diff, dev = _col(w, f"{act}_diff", when), _col(w, f"{act}_device", when)
    less, wout = _col(w, f"{act}_less", when), _col(w, f"{act}_wout", when)
    lvl = np.where(np.nan_to_num(dev) + np.nan_to_num(less) > 0, 1.0, 0.0)
    lvl = np.where(np.nan_to_num(diff) >= 1, 2.0, lvl)
    lvl = np.where(np.nan_to_num(wout) >= 1, 3.0, lvl)
    return np.where(np.isnan(diff) & np.isnan(dev), np.nan, lvl)


def _snapshot(w, when):
    f = {k: _level(w, a, when) for k, a in AREAS.items()}
    f["out"] = _col(w, "go_out_freq", when)
    f["fall"] = _col(w, "fell_last_year", when)
    f["energy"] = _col(w, "low_energy", when)
    f["pain"] = _col(w, "pain_limits", when)
    dem = _col(w, "dementia_class", when)
    f["memory"] = np.where(np.isnan(dem), np.nan, (dem >= 1).astype(float))
    ph = _col(w, "phq2", when)
    f["mood"] = np.where(np.isnan(ph), np.nan, (ph >= 3).astype(float))
    parts = [np.fmax(_col(w, f"iadl_{t}_diff", when), _col(w, f"iadl_{t}_hhelp", when)) for t in TASKS]
    stack = np.vstack(parts)
    f["iadl"] = np.where(np.isnan(stack).all(axis=0), np.nan, np.nansum(stack, axis=0))
    f["walk"] = _col(w, "cannot_walk_6blocks", when)
    ct, pu = _col(w, "chair_time", when), _col(w, "perf_unable", when)
    f["chair"] = np.where(ct >= 15, 1.0, np.where(ct < 15, 0.0, np.where(pu >= 1, 1.0, np.nan)))
    f["hospital"] = _col(w, "hospital_stay", when)
    f["weight"] = _col(w, "weight_loss_10lb", when)
    return f


CHANGE_KEYS = list(AREAS) + ["out", "iadl", "memory", "walk", "chair"]


def app_features(w: pd.DataFrame) -> pd.DataFrame:
    cur, prev = _snapshot(w, "cur"), _snapshot(w, "prev")
    X = {f"now_{k}": v for k, v in cur.items()}
    for k in CHANGE_KEYS:
        X[f"chg_{k}"] = cur[k] - prev[k]
    X["n_declines"] = sum(np.nan_to_num(X[f"chg_{k}"]) > 0 for k in CHANGE_KEYS).astype(float)
    X["age"] = w["age"].astype(float).values
    return pd.DataFrame(X, index=w.index)


def fit_app_model(train, test, outcome="y_any", seed=0, log=print):
    Xtr, Xte = app_features(train), app_features(test)
    y, yte = train[outcome].astype(int).values, test[outcome].astype(int).values
    center = Xtr.mean()
    scale = Xtr.std().replace(0, 1).fillna(1)
    Ztr = ((Xtr - center) / scale).fillna(0)
    Zte = ((Xte - center) / scale).fillna(0)
    folds = list(GroupKFold(5).split(Ztr, y, train.person_id.values))
    best = None
    for C in [0.01, 0.03, 0.1, 0.3, 1.0]:
        oof = np.zeros(len(y))
        for tr, va in folds:
            oof[va] = LogisticRegression(C=C, max_iter=3000).fit(Ztr.iloc[tr], y[tr]).predict_proba(Ztr.iloc[va])[:, 1]
        auc = roc_auc_score(y, oof)
        if best is None or auc > best[1]:
            best = (C, auc)
    m = LogisticRegression(C=best[0], max_iter=3000).fit(Ztr, y)
    p_tr = m.predict_proba(Ztr)[:, 1]
    p = m.predict_proba(Zte)[:, 1]
    boot = ev.cluster_bootstrap(test, {"app": p}, outcome, B=300, seed=seed)
    met = ev.core_metrics(yte, p)
    log(f"[app-model] C={best[0]} CV AUROC {best[1]:.3f} | test AUROC {met['auroc']:.3f} "
        f"({boot.auroc_lo.iloc[0]:.3f}-{boot.auroc_hi.iloc[0]:.3f})  O/E {met['obs_exp']:.2f}  slope {met['cal_slope']:.2f}")
    feats = []
    for i, name in enumerate(Xtr.columns):
        key = name.split("_", 1)[1] if "_" in name else name
        feats.append({"name": name, "label": LABELS.get(key, name), "coef": float(m.coef_[0, i]),
                      "center": float(center[name]), "scale": float(scale[name])})
    return {
        "model": "logistic (L2), NHATS-trained, app question set",
        "trained_on": "NHATS public-use Rounds 1-14 (2011-2024), community-dwelling adults 65+ without help",
        "outcome": "help from another person with mobility or self-care within ~1 year",
        "n_train_windows": int(len(train)), "n_test_windows": int(len(test)),
        "cv_auroc": float(best[1]), "C": best[0],
        "test": {"auroc": float(met["auroc"]), "auroc_lo": float(boot.auroc_lo.iloc[0]),
                 "auroc_hi": float(boot.auroc_hi.iloc[0]), "auprc": float(met["auprc"]),
                 "obs_exp": float(met["obs_exp"]), "cal_slope": float(met["cal_slope"]),
                 "base_rate": float(yte.mean())},
        "thresholds": {"watch": float(np.quantile(p_tr, 0.6)), "talk": float(np.quantile(p_tr, 0.8))},
        "intercept": float(m.intercept_[0]),
        "features": feats,
        "note": "Aggregate parameters only. Trained on yearly change; weekly/monthly use needs prospective validation.",
    }


def export(source, nhats_dir, out_path, outcome="y_any", log=print):
    from .features import build_windows
    from .pipeline import load
    panel = load(source, nhats_dir)
    windows = build_windows(panel)
    analytic = windows[windows[outcome].notna()].copy()
    analytic[outcome] = analytic[outcome].astype(int)
    split_round = int(analytic["round"].max()) - 3
    train, test = ev.temporal_person_split(analytic, split_round, seed=0)
    res = fit_app_model(train, test, outcome, log=log)
    res["source"] = source
    with open(out_path, "w") as f:
        json.dump(res, f, indent=1)
    log(f"[app-model] wrote {out_path}")
    return res
