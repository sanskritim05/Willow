"""Paper outputs: Table 1 + cohort flow, fairness mitigation, publication figures.

Everything written here is aggregate (counts, percentages, metrics). Cells < 11 are suppressed.
"""
from __future__ import annotations

import os

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from . import evaluate as ev
from .schema import HELP_COLS

MIN_CELL = 11


def _pct(n, d):
    if d == 0:
        return "—"
    if 0 < n < MIN_CELL:
        return f"<{MIN_CELL}"
    return f"{n:,} ({100 * n / d:.1f}%)"


# ------------------------------------------------------------------ Table 1 and flow
def cohort_flow(panel, windows, analytic, train, test):
    comm = panel[panel.status == "community"]
    ph = comm.set_index(["person_id", "round"])
    rows = [("Sample persons, rounds 1–14", panel.person_id.nunique()),
            ("Person-rounds living in the community", len(comm)),
            ("…with a community interview the year before (t-1)", None),
            ("At-risk windows: no help with any of 7 activities at t", len(windows)),
            ("…outcome observed in the community at t+1 (analytic windows)", len(analytic)),
            ("…exited before t+1: died", int((windows.exit_next == "deceased").sum())),
            ("…exited before t+1: moved to nursing home / residential care",
             int(windows.exit_next.isin(["nursing_home", "residential_care"]).sum())),
            ("Training windows (outcome year ≤ split; 70% of people)", len(train)),
            ("Test windows (later years; the other 30% of people)", len(test))]
    prev = comm[["person_id", "round"]].copy()
    prev["round"] += 1
    rows[2] = (rows[2][0], len(comm.merge(prev, on=["person_id", "round"])))
    return pd.DataFrame(rows, columns=["step", "n"])


def table1(analytic, outcome):
    """Characteristics at each person's FIRST analytic window, by whether they newly needed help then."""
    first = analytic.sort_values("round").groupby("person_id").head(1)
    cols = {
        "Age 65–74": lambda d: d.age < 75, "Age 75–84": lambda d: (d.age >= 75) & (d.age < 85),
        "Age 85+": lambda d: d.age >= 85, "Female": lambda d: d.female == 1,
        "White, non-Hispanic": lambda d: d.race_eth == "white", "Black, non-Hispanic": lambda d: d.race_eth == "black",
        "Hispanic": lambda d: d.race_eth == "hispanic", "Other / missing race": lambda d: ~d.race_eth.isin(["white", "black", "hispanic"]),
        "Lives alone": lambda d: d.lives_alone == 1, "Medicaid": lambda d: d.get("medicaid", pd.Series(np.nan, index=d.index)) == 1,
        "Proxy respondent": lambda d: d.proxy == 1,
        "Possible dementia": lambda d: d["dementia_class__cur"] == 1, "Probable dementia": lambda d: d["dementia_class__cur"] == 2,
        "Any mobility/self-care difficulty (no help)": lambda d: d[[c for c in d.columns if c.endswith("_diff__cur") and not c.startswith("iadl")]].fillna(0).sum(axis=1) > 0,
        "Any device use": lambda d: d[[c for c in d.columns if c.endswith("_device__cur")]].fillna(0).sum(axis=1) > 0,
        "Cannot walk 6 blocks": lambda d: d.get("cannot_walk_6blocks__cur", pd.Series(np.nan, index=d.index)) == 1,
        "Health-related help with a household task": lambda d: d[[c for c in d.columns if c.endswith("_hhelp__cur")]].fillna(0).sum(axis=1) > 0 if any(c.endswith("_hhelp__cur") for c in d.columns) else pd.Series(False, index=d.index),
        "Hospital stay in past year": lambda d: d["hospital_stay__cur"] == 1,
    }
    groups = {"All people": first, "Newly needed help at t+1": first[first[outcome] == 1],
              "Did not": first[first[outcome] == 0]}
    out = {"Characteristic": ["N (people)"]}
    for g, d in groups.items():
        out[g] = [f"{len(d):,}"]
    for label, f in cols.items():
        out["Characteristic"].append(label)
        for g, d in groups.items():
            try:
                out[g].append(_pct(int(f(d).sum()), len(d)))
            except Exception:
                out[g].append("—")
    out["Characteristic"].append("Mean number of chronic conditions")
    for g, d in groups.items():
        v = d.get("n_chronic__cur")
        out[g].append("—" if v is None or v.isna().all() else f"{v.mean():.1f}")
    return pd.DataFrame(out)


# ------------------------------------------------------------------ fairness mitigation
def _platt(p, y):
    return ev.LogisticRegression(C=1e6, max_iter=1000).fit(ev._logit(p).reshape(-1, 1), y)


def _apply(m, p):
    return m.predict_proba(ev._logit(p).reshape(-1, 1))[:, 1]


def group_recalibrate(oof, y, g_train, raw_test, g_test):
    out = np.zeros(len(raw_test))
    for g in np.unique(g_test):
        tr, te = g_train == g, g_test == g
        m = _platt(oof[tr], y[tr]) if tr.sum() > 200 and 0 < y[tr].sum() < tr.sum() else _platt(oof, y)
        out[te] = _apply(m, raw_test[te])
    return out


def fairness_mitigation(train, test, outcome, oof_raw, test_raw, thr_global):
    """Compare global recalibration with group-specific recalibration (fit on TRAINING out-of-fold
    predictions only). Race-aware recalibration uses race at prediction time: reported as an
    analysis of the gap, not as a deployment recommendation."""
    from .tuning import race_calibration_gap
    y_tr, y_te = train[outcome].values.astype(int), test[outcome].values.astype(int)
    glob = _apply(_platt(oof_raw, y_tr), test_raw)
    med_tr = train["medicaid"].fillna(0).values if "medicaid" in train else np.zeros(len(train))
    med_te = test["medicaid"].fillna(0).values if "medicaid" in test else np.zeros(len(test))
    bh_tr = train.race_eth.isin(["black", "hispanic"]).values.astype(int)
    bh_te = test.race_eth.isin(["black", "hispanic"]).values.astype(int)
    strategies = {
        "Global recalibration (as reported)": glob,
        "Recalibrated within Medicaid groups": group_recalibrate(oof_raw, y_tr, med_tr, test_raw, med_te),
        "Recalibrated within race groups (Black+Hispanic vs other)": group_recalibrate(oof_raw, y_tr, bh_tr, test_raw, bh_te),
    }
    rows = []
    for name, p in strategies.items():
        gap = race_calibration_gap(test, p, outcome)
        r = {"strategy": name, "auroc": roc_auc_score(y_te, p), "obs_exp": y_te.mean() / p.mean(),
             "oe_black_hispanic": gap["oe_black_hispanic"], "oe_white": gap["oe_white"],
             "race_gap": gap["difference"], "race_gap_lo": gap["difference_ci"][0], "race_gap_hi": gap["difference_ci"][1]}
        for lvl, m in (("medicaid", med_te == 1), ("no_medicaid", med_te == 0)):
            r[f"oe_{lvl}"] = y_te[m].mean() / p[m].mean() if m.sum() else np.nan
        flag = p >= thr_global
        for lvl, m in (("black_hispanic", bh_te == 1), ("white", (test.race_eth == "white").values)):
            pos = m & (y_te == 1)
            r[f"sens_{lvl}"] = flag[pos].mean() if pos.sum() else np.nan
        rows.append(r)
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ figures
SERIES = ["#2a78d6", "#eb6834", "#1baf7a"]
INK, MUTED, GRID = "#0b0b0b", "#898781", "#e1e0d9"


def _style(ax, title):
    ax.set_title(title, loc="left", fontsize=10.5, color=INK)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#c3c2b7")
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.grid(color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)


def paper_figures(out_dir, test, outcome, preds: dict, fair: pd.DataFrame, imp: pd.DataFrame):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    y = test[outcome].values
    labels = list(preds)
    # Figure 2: calibration + decision curve
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
    ax = axes[0]
    mx = 0
    for i, k in enumerate(labels):
        c = ev.calibration_bins(y, preds[k])
        mx = max(mx, c.mean_pred.max(), c.obs_rate.max())
        ax.plot(c.mean_pred, c.obs_rate, marker="o", ms=4, lw=2, color=SERIES[i], label=k)
    ax.plot([0, mx * 1.05], [0, mx * 1.05], ls="--", lw=1, color=MUTED, label="perfect calibration")
    ax.set_xlabel("Predicted risk", color=MUTED, fontsize=8); ax.set_ylabel("Observed rate", color=MUTED, fontsize=8)
    _style(ax, "A. Calibration (test set, deciles)"); ax.legend(fontsize=7, frameon=False)
    ax = axes[1]
    for i, k in enumerate(labels):
        d = ev.decision_curve(y, preds[k])
        ax.plot(d.threshold, d.net_benefit, lw=2, color=SERIES[i], label=k)
    ax.plot(d.threshold, d.treat_all, ls="--", lw=1, color=MUTED, label="review everyone")
    ax.axhline(0, color="#c3c2b7", lw=1)
    ax.set_xlim(0.02, 0.4); ax.set_ylim(-0.01, max(0.02, y.mean()) * 1.1)
    ax.set_xlabel("Risk threshold for professional review", color=MUTED, fontsize=8)
    ax.set_ylabel("Net benefit", color=MUTED, fontsize=8)
    _style(ax, "B. Decision curve"); ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "paper_fig2_calibration_dca.png"), dpi=300); plt.close(fig)

    # Figure 3: subgroup forest plot (AUROC and O/E with CIs)
    f = fair[fair.auroc.notna()].copy() if "auroc" in fair else fair.iloc[0:0]
    if len(f):
        names = {"race_eth": "", "female": "Sex", "medicaid": "Medicaid", "lives_alone": "Lives alone", "proxy": "Proxy",
                 "dementia_any": "Dementia (possible/probable)", "age_85plus": "Age 85+"}
        lab = [f"{names.get(r.subgroup, r.subgroup)} {r.level}".strip().replace(" 1.0", ": yes").replace(" 0.0", ": no")
               .replace(" 1", ": yes").replace(" 0", ": no") for r in f.itertuples()]
        yy = np.arange(len(f))[::-1]
        fig, axes = plt.subplots(1, 2, figsize=(10, 0.32 * len(f) + 1.4), sharey=True)
        for ax, (m, lo, hi, ref, title) in zip(axes, [("auroc", "auroc_lo", "auroc_hi", None, "A. AUROC by subgroup"),
                                                      ("obs_exp", "obs_exp_lo", "obs_exp_hi", 1.0, "B. Observed / expected (>1 = under-estimated)")]):
            ax.errorbar(f[m], yy, xerr=[f[m] - f[lo], f[hi] - f[m]], fmt="o", color=SERIES[0], ms=5, capsize=2, lw=1.2)
            if ref:
                ax.axvline(ref, color=MUTED, ls="--", lw=1)
            _style(ax, title)
        axes[0].set_yticks(yy); axes[0].set_yticklabels(lab, fontsize=8)
        fig.tight_layout(); fig.savefig(os.path.join(out_dir, "paper_fig3_subgroups.png"), dpi=300); plt.close(fig)

    # Figure 4: which declines raise risk
    w = imp[imp.direction == "worse"].sort_values("mean_contribution", ascending=True)
    none = imp[imp.direction == "none"]
    fig, axes = plt.subplots(1, 2, figsize=(10, 0.3 * len(w) + 1.4), sharey=True,
                             gridspec_kw={"width_ratios": [1.3, 1]})
    axes[0].barh(w.group, w.mean_contribution * 100, color=SERIES[0], height=0.6)
    axes[0].set_xlabel("Mean rise in predicted risk attributable to the decline (points)", color=MUTED, fontsize=8)
    _style(axes[0], "A. Model: what each decline adds")
    axes[1].barh(w.group, w.observed_new_help * 100, color=SERIES[1], height=0.6)
    if len(none):
        axes[1].axvline(none.observed_new_help.iloc[0] * 100, color=MUTED, ls="--", lw=1)
        axes[1].text(none.observed_new_help.iloc[0] * 100 + 0.3, -0.6, "no decline in any area", fontsize=7, color=MUTED)
    axes[1].set_xlabel("Observed rate of new help within a year (%)", color=MUTED, fontsize=8)
    _style(axes[1], "B. Data: new help among people with the decline")
    axes[0].tick_params(axis="y", labelsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "paper_fig4_declines.png"), dpi=300); plt.close(fig)
