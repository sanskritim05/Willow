"""Load real NHATS round files into the canonical long panel.

Runs ONLY on your own computer. NHATS conditions of use forbid uploading the data to
public AI tools, so never paste these files (or row-level outputs) into a chatbot.

Every variable name comes from config/variables.yaml, which must be verified against
the NHATS codebooks first (`python -m early_signals inspect --nhats-dir ...`).
"""
from __future__ import annotations

import glob
import os
import warnings

import numpy as np
import pandas as pd
import yaml

from . import dementia, nhats_extra
from .schema import EXTRA_ITEMS

HERE = os.path.dirname(__file__)
DEFAULT_CONFIG = os.path.abspath(os.path.join(HERE, "..", "..", "config", "variables.yaml"))


def load_config(path: str | None = None) -> dict:
    with open(path or DEFAULT_CONFIG) as f:
        return yaml.safe_load(f)


def _header(path: str) -> list[str]:
    """Variable names only (no respondent rows)."""
    if path.lower().endswith(".dta"):
        with pd.io.stata.StataReader(path) as rd:
            return [c.lower() for c in rd.variable_labels()]
    return list(_read_any(path).columns)


def _read_any(path: str, columns=None) -> pd.DataFrame:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".dta":
        if columns is not None:
            hdr = {c.lower(): c for c in pd.io.stata.StataReader(path).variable_labels()}
            columns = list(dict.fromkeys(hdr[c] for c in columns if c in hdr))
        df = pd.read_stata(path, convert_categoricals=False, columns=columns)
    elif ext == ".sas7bdat":
        df = pd.read_sas(path)
    elif ext == ".csv":
        df = pd.read_csv(path, low_memory=False)
    else:
        raise ValueError(f"Unsupported file type: {path}")
    df.columns = [c.lower() for c in df.columns]
    return df


def _find(nhats_dir: str, pattern: str, r: int):
    hits = sorted(glob.glob(os.path.join(nhats_dir, "**", pattern.format(r=r)), recursive=True))
    hits = [h for h in hits if os.path.splitext(h)[1].lower() in (".dta", ".sas7bdat", ".csv")]
    return hits[0] if hits else None


def _recode(series: pd.Series, rule):
    num = pd.to_numeric(series, errors="coerce")
    if rule is None:  # identity: keep valid codes, negative NHATS missing codes -> NaN
        return num.where(num >= 0)
    rule = dict(rule)
    default = rule.pop("_default", None)
    out = num.map(rule)
    if default is not None:
        out = out.where(out.notna() | ~(num >= 0), default)
    return out


def rounds_available(nhats_dir: str, cfg: dict):
    return [r for r in range(1, 30) if _find(nhats_dir, cfg["files"]["sp_file"], r)]


def inspect(nhats_dir: str, cfg: dict | None = None) -> pd.DataFrame:
    """Report which configured variables are missing from each round's SP file."""
    cfg = cfg or load_config()
    rows = []
    for r in rounds_available(nhats_dir, cfg):
        cols = set(_header(_find(nhats_dir, cfg["files"]["sp_file"], r)))
        for name, spec in cfg["items"].items():
            if "nhats" in spec:
                v = spec["nhats"].format(r=r)
                rows.append({"round": r, "canonical": name, "nhats_var": v, "found": v in cols})
        for v in cfg["derived"]["phq2"]["items"]:
            rows.append({"round": r, "canonical": "phq2", "nhats_var": v.format(r=r),
                         "found": v.format(r=r) in cols})
    return pd.DataFrame(rows)


def load_panel(nhats_dir: str, cfg: dict | None = None) -> pd.DataFrame:
    cfg = cfg or load_config()
    if not cfg.get("verified"):
        warnings.warn("config/variables.yaml is not marked verified: results are NOT trustworthy until every "
                      "variable name and code has been checked against the NHATS codebooks.")
    idcol = cfg["id"]
    frames = []
    seen: set = set()
    for r in rounds_available(nhats_dir, cfg):
        path = _find(nhats_dir, cfg["files"]["sp_file"], r)
        wanted = [idcol] + [s["nhats"].format(r=r) for s in cfg["items"].values() if "nhats" in s]
        wanted += [i.format(r=r) for i in cfg["derived"]["phq2"]["items"]]
        wanted += dementia.source_columns(r)
        wanted += nhats_extra.source_columns(r)
        raw = _read_any(path, columns=wanted)
        df = pd.DataFrame({"person_id": raw[idcol].values, "round": r})
        for name, spec in cfg["items"].items():
            if "nhats" not in spec:
                continue
            v = spec["nhats"].format(r=r)
            rule = cfg["recodes"].get(spec["recode"]) if spec["recode"] != "identity" else None
            df[name] = _recode(raw[v], rule).values if v in raw.columns else np.nan
        # derived
        ph = cfg["derived"]["phq2"]
        parts = [_recode(raw[i.format(r=r)], ph["recode"]) for i in ph["items"] if i.format(r=r) in raw.columns]
        df["phq2"] = sum(parts).values if len(parts) == len(ph["items"]) else np.nan
        # official NHATS dementia classification (Technical Paper #5 algorithm, ported in dementia.py);
        # falls back to the reported-diagnosis item from the config if the cognition items are absent
        dc = dementia.to_canonical(dementia.classify(raw, r))
        if dc.notna().any():
            df["dementia_class"] = dc.values
        dm = cfg["derived"].get("dementia")  # optional: override with a precomputed column
        if dm:
            dcol = dm["column"].format(r=r)
            if dcol in raw.columns:
                df["dementia_class"] = _recode(raw[dcol], dm["recode"]).values
        # expanded measures (IADLs, physical capacity/performance, symptoms, conditions, Medicaid)
        ext = nhats_extra.derive(raw, r)
        for c in ext.columns:
            df[c] = ext[c].values
        # age & status
        df["age"] = df.pop("age_cat").map(cfg["age_cat_midpoints"])
        df["status"] = df.pop("residence").fillna("nonresponse")
        df["cohort"] = np.where(df["person_id"].isin(seen), np.nan, r)
        seen |= set(df["person_id"])
        frames.append(df)
    panel = pd.concat(frames, ignore_index=True)
    panel["cohort"] = panel.groupby("person_id")["cohort"].transform("min")
    # persons missing from a round after entry (and not known to have exited) are nonresponse rows
    items = [c for c in panel.columns if c.endswith(("_help", "_diff", "_device", "_less", "_wout"))]
    items = list(dict.fromkeys(items + [c for c in EXTRA_ITEMS if c in panel.columns]))
    panel.loc[panel["status"] != "community", items] = np.nan
    for c in ["female", "race_eth"]:  # time-invariant: carry forward/back
        panel[c] = panel.groupby("person_id")[c].transform(lambda s: s.ffill().bfill())
    panel["source"] = "nhats"
    return panel.sort_values(["person_id", "round"]).reset_index(drop=True)
