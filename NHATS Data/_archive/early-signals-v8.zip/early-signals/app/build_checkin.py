"""Build the Steady check-in app (app/index.html).

  python app/build_checkin.py                      # provisional weights
  python app/build_checkin.py --model app_model.json   # embed the NHATS-trained app model

app_model.json comes from `python -m early_signals export-app-model --nhats-dir ...` and holds
aggregate model coefficients only.
"""
import argparse
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

ap = argparse.ArgumentParser()
ap.add_argument("--model")
a = ap.parse_args()
html = open(os.path.join(HERE, "checkin.html")).read()
if a.model:
    m = json.load(open(a.model))
    if m.get("source") == "synthetic":
        raise SystemExit("Refusing to ship a model trained on synthetic data as if it were real.")
    html = html.replace("/*APP_MODEL*/null", json.dumps(m, separators=(",", ":")))
open(os.path.join(HERE, "index.html"), "w").write(html)
print("wrote app/index.html", "(NHATS-trained model)" if a.model else "(provisional weights)")
