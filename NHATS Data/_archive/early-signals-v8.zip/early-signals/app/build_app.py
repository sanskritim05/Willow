"""Build app/index.html from pipeline outputs.  Usage: python app/build_app.py [outputs_dir]

Only synthetic personas are ever embedded. With real NHATS outputs the app shows the
aggregate model card only; row-level NHATS data must never go into a shared page.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def _round(o):
    if isinstance(o, float):
        return round(o, 4)
    if isinstance(o, dict):
        return {k: _round(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_round(v) for v in o]
    return o


def main(out_dir="outputs"):
    card = json.load(open(os.path.join(out_dir, "model_card.json")))
    personas = []
    ppath = os.path.join(out_dir, "personas.json")
    if card.get("is_synthetic") and os.path.exists(ppath):
        personas = json.load(open(ppath))
    elif os.path.exists(ppath):
        sys.exit("Refusing to embed personas from non-synthetic data.")
    tpl = open(os.path.join(HERE, "template.html")).read()
    html = (tpl.replace("/*PERSONAS*/[]", json.dumps(_round(personas), separators=(",", ":")))
               .replace("/*CARD*/{}", json.dumps(_round(card), separators=(",", ":"))))
    dest = os.path.join(HERE, "research.html")
    open(dest, "w").write(html)
    print(f"wrote {dest} ({len(html) / 1024:.0f} KB, {len(personas)} synthetic personas)")


if __name__ == "__main__":
    main(*sys.argv[1:])
