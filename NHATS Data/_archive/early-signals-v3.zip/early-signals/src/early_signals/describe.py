"""Aggregate sanity-check tables (safe to share: counts only, small cells suppressed)."""
from __future__ import annotations

import pandas as pd

from .features import build_windows
from .schema import HELP_COLS

MIN_CELL = 11  # suppress any count below this (common small-cell rule; check NHATS guidance)


def _sup(n):
    return n if (n == 0 or n >= MIN_CELL) else f"<{MIN_CELL}"


def describe(panel: pd.DataFrame) -> str:
    out = []
    first = panel.groupby("person_id")["round"].min()
    out.append(f"People: {panel.person_id.nunique():,}  |  person-rounds: {len(panel):,}")
    out.append("New people by entry round: " + ", ".join(f"R{r}: {_sup(n):,}" if isinstance(_sup(n), int)
                                                         else f"R{r}: {_sup(n)}" for r, n in first.value_counts().sort_index().items()))
    st = panel.pivot_table(index="round", columns="status", values="person_id", aggfunc="count").fillna(0).astype(int)
    out.append("\nStatus by round (rows = round):\n" + st.map(_sup).to_string())
    comm = panel[panel.status == "community"]
    anyhelp = (comm[HELP_COLS].sum(axis=1, min_count=7) > 0)
    miss = comm[HELP_COLS].isna().any(axis=1)
    t = pd.DataFrame({"community": comm.groupby("round").size(),
                      "any_help_%": (anyhelp[~miss].groupby(comm.loc[~miss, "round"]).mean() * 100).round(1),
                      "help_items_missing_%": (miss.groupby(comm["round"]).mean() * 100).round(1)})
    out.append("\nCommunity residents receiving help with >=1 of 7 activities (unweighted):\n" + t.to_string())
    w = build_windows(panel)
    a = w[w.y_any.notna()]
    inc = a.groupby("round").agg(windows=("y_any", "size"), new_help_pct=("y_any", "mean"))
    inc["new_help_pct"] = (inc.new_help_pct * 100).round(1)
    ex = w.groupby("round").exit_next.value_counts().unstack(fill_value=0)
    out.append(f"\nAt-risk windows: {len(w):,}; with outcome observed in community: {len(a):,}")
    out.append("Yearly incidence of NEW help among at-risk (by anchor round t; outcome at t+1):\n" + inc.to_string())
    out.append("\nWhat happened at t+1 to at-risk people:\n" + ex.map(_sup).to_string())
    cov = w.drop(columns=[c for c in w.columns if not c.endswith("__cur")]).notna().mean().sort_values()
    out.append("\nLeast-complete items among at-risk windows (share non-missing):\n" + cov.head(12).round(3).to_string())
    return "\n".join(out)
