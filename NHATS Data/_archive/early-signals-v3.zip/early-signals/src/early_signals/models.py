"""Model zoo: logistic regression (status-only baseline and change-aware) vs tree ensembles."""
from __future__ import annotations

from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

try:  # optional, used when installed (pip install xgboost)
    from xgboost import XGBClassifier  # type: ignore
    HAS_XGB = True
except Exception:  # pragma: no cover
    HAS_XGB = False


def logistic(C: float = 0.5):
    return make_pipeline(SimpleImputer(strategy="median", add_indicator=True), StandardScaler(),
                         LogisticRegression(C=C, max_iter=2000))


def random_forest(seed: int = 0):
    return make_pipeline(SimpleImputer(strategy="median", add_indicator=True),
                         RandomForestClassifier(n_estimators=400, min_samples_leaf=25, max_features="sqrt",
                                                n_jobs=-1, random_state=seed))


def gradient_boosting(seed: int = 0):
    if HAS_XGB:
        return XGBClassifier(n_estimators=500, learning_rate=0.03, max_depth=4, subsample=0.8,
                             colsample_bytree=0.8, min_child_weight=10, reg_lambda=1.0,
                             eval_metric="logloss", random_state=seed, n_jobs=-1)
    return HistGradientBoostingClassifier(learning_rate=0.04, max_iter=400, max_leaf_nodes=15,
                                          min_samples_leaf=40, l2_regularization=1.0, random_state=seed)


def model_specs():
    """name -> (feature_set, factory). The first entry is the reference baseline."""
    gb_name = "xgboost" if HAS_XGB else "hist_gradient_boosting"
    return {
        "logistic_status_only": ("status", logistic),
        "logistic_change": ("change", logistic),
        "random_forest_change": ("change", random_forest),
        f"{gb_name}_change": ("change", gradient_boosting),
    }
