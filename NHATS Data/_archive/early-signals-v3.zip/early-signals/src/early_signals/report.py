"""Markdown report + figures (paper-ready drafts)."""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
INK, MUTED, GRID = "#0b0b0b", "#898781", "#e1e0d9"


def _style(ax, title):
    ax.set_title(title, loc="left", fontsize=11, color=INK)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#c3c2b7")
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.grid(color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)


def _pretty(name):
    return name.replace("_change", " + changes").replace("_status_only", " (status only)").replace("_", " ")


def figures(out_dir, calib, dca, fair, importance, primary):
    names = list(dict.fromkeys(calib.model))
    fig, ax = plt.subplots(figsize=(5, 4.2))
    mx = max(calib.mean_pred.max(), calib.obs_rate.max()) * 1.05
    ax.plot([0, mx], [0, mx], color=MUTED, lw=1, ls="--", label="perfect calibration")
    for i, m in enumerate(names):
        c = calib[calib.model == m]
        ax.plot(c.mean_pred, c.obs_rate, marker="o", ms=4, lw=2, color=SERIES[i], label=_pretty(m))
    ax.set_xlabel("Predicted risk", color=MUTED); ax.set_ylabel("Observed rate", color=MUTED)
    _style(ax, "Calibration (test set, deciles)"); ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_calibration.png"), dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.5, 4.2))
    base = dca[dca.model == names[0]]
    ax.plot(base.threshold, base.treat_all, color=MUTED, lw=1, ls="--", label="review everyone")
    ax.axhline(0, color="#c3c2b7", lw=1, label="review no one")
    for i, m in enumerate(names):
        d = dca[dca.model == m]
        ax.plot(d.threshold, d.net_benefit, lw=2, color=SERIES[i], label=_pretty(m))
    ax.set_ylim(-0.02, max(dca.net_benefit.max(), 0.02) * 1.15); ax.set_xlim(0.02, 0.4)
    ax.set_xlabel("Risk threshold for review", color=MUTED); ax.set_ylabel("Net benefit", color=MUTED)
    _style(ax, "Decision curve"); ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_decision_curve.png"), dpi=160); plt.close(fig)

    f = fair[(fair.model == primary) & fair.sensitivity.notna()] if "sensitivity" in fair else fair.iloc[0:0]
    if len(f):
        fig, ax = plt.subplots(figsize=(6, 0.28 * len(f) + 1))
        labels = [f"{r.subgroup} = {r.level}" for r in f.itertuples()]
        ax.barh(labels, f.sensitivity, color=SERIES[0], height=0.6)
        ax.invert_yaxis(); ax.set_xlim(0, 1); ax.set_xlabel("Sensitivity at alert threshold", color=MUTED)
        _style(ax, "Who gets missed? Sensitivity by subgroup (primary model)")
        fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_subgroup_sensitivity.png"), dpi=160); plt.close(fig)

    imp = importance.head(10)
    fig, ax = plt.subplots(figsize=(6, 0.32 * len(imp) + 1))
    ax.barh(imp.group, imp.mean_contribution * 100, color=SERIES[0], height=0.6)
    ax.invert_yaxis(); ax.set_xlabel("Mean change in predicted risk when the change occurred (percentage points)",
                                     color=MUTED, fontsize=8)
    _style(ax, "Which changes move risk most")
    fig.tight_layout(); fig.savefig(os.path.join(out_dir, "fig_change_importance.png"), dpi=160); plt.close(fig)


def write_report(out_dir, metrics, boot, fair, sens, importance, calib, dca, primary, source):
    figures(out_dir, calib, dca, fair, importance, primary)
    m = metrics.merge(boot, on="model", how="left")
    lines = [f"# Early Signals — results ({source} data)", ""]
    if source == "synthetic":
        lines += ["> **Synthetic data.** These numbers only show the pipeline works. They say nothing about "
                  "real older adults.", ""]
    lines += ["## Discrimination, calibration, and alerting (held-out people, later rounds)", "",
              "| Model | AUROC (95% CI) | AUPRC | Brier | O/E | Cal. slope | Sensitivity | PPV | Alert rate |",
              "|---|---|---|---|---|---|---|---|---|"]
    for r in m.itertuples():
        lines.append(f"| {_pretty(r.model)} | {r.auroc:.3f} ({r.auroc_lo:.3f}–{r.auroc_hi:.3f}) | {r.auprc:.3f} | "
                     f"{r.brier:.3f} | {r.obs_exp:.2f} | {r.cal_slope:.2f} | {r.sensitivity:.2f} | {r.ppv:.2f} | "
                     f"{r.alert_rate:.2f} |")
    g = m.dropna(subset=["auroc_gain_vs_baseline"])
    lines += ["", "**AUROC gain over status-only logistic regression (paired, person-clustered bootstrap):**", ""]
    lines += [f"- {_pretty(r.model)}: +{r.auroc_gain_vs_baseline:.3f} ({r.gain_lo:.3f} to {r.gain_hi:.3f})"
              for r in g.itertuples()]
    lines += ["", "![calibration](fig_calibration.png)", "", "![decision curve](fig_decision_curve.png)", "",
              "## Subgroup audit (primary model)", "",
              "| Subgroup | Level | n | Prev. | AUROC | O/E | Sensitivity | FNR | FPR |", "|---|---|---|---|---|---|---|---|---|"]
    for r in fair[fair.model == primary].itertuples():
        if getattr(r, "auroc", None) == getattr(r, "auroc", None) and hasattr(r, "auroc"):
            lines.append(f"| {r.subgroup} | {r.level} | {r.n} | {r.prevalence:.3f} | {r.auroc:.3f} | {r.obs_exp:.2f} | "
                         f"{r.sensitivity:.2f} | {r.fnr:.2f} | {r.fpr:.2f} |")
    lines += ["", "![subgroups](fig_subgroup_sensitivity.png)", "", "## Which changes drive risk", "",
              "Mean change in predicted risk if that change had not happened (counterfactual, among people "
              "who had the change).", "", "| Change | People with change | Mean contribution (pts) |", "|---|---|---|"]
    for r in importance.itertuples():
        lines.append(f"| {r.group} | {r.n_changed:,} | {r.mean_contribution * 100:+.1f} |")
    lines += ["", "![changes](fig_change_importance.png)", "", "## Sensitivity analyses (primary model)", "",
              "| Outcome | n | Prevalence | AUROC | AUPRC |", "|---|---|---|---|---|"]
    for r in sens.itertuples():
        lines.append(f"| {r.outcome} | {r.n:,} | {r.prevalence:.3f} | {r.auroc:.3f} | {r.auprc:.3f} |")
    with open(os.path.join(out_dir, "report.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
