"""Splitting, discrimination/calibration metrics, decision curves, subgroup (fairness) audits."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score


# ---------------------------------------------------------------- splitting
def temporal_person_split(w: pd.DataFrame, split_round: int, test_frac: float = 0.3, seed: int = 0):
    """Person-disjoint AND time-ordered split.

    train: training persons, windows whose OUTCOME round (t+1) is <= split_round
    test : held-out persons, windows anchored at t >= split_round (strictly later outcomes)
    """
    rng = np.random.default_rng(seed)
    persons = w["person_id"].unique()
    test_persons = set(rng.choice(persons, int(len(persons) * test_frac), replace=False))
    is_test_person = w["person_id"].isin(test_persons)
    train = w[~is_test_person & (w["round"] + 1 <= split_round)]
    test = w[is_test_person & (w["round"] >= split_round)]
    return train.copy(), test.copy()


# ---------------------------------------------------------------- metrics
def _logit(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def calibration_slope(y, p, w=None):
    lr = LogisticRegression(C=1e6, max_iter=1000)
    lr.fit(_logit(p).reshape(-1, 1), y, sample_weight=w)
    return float(lr.coef_[0, 0])


def core_metrics(y, p, w=None) -> dict:
    y, p = np.asarray(y), np.asarray(p)
    wm = None if w is None else np.asarray(w)
    out = {"n": int(len(y)), "events": int(y.sum()),
           "prevalence": float(np.average(y, weights=wm))}
    if len(np.unique(y)) < 2:
        return out
    out.update({
        "auroc": roc_auc_score(y, p, sample_weight=wm),
        "auprc": average_precision_score(y, p, sample_weight=wm),
        "brier": brier_score_loss(y, p, sample_weight=wm),
        "obs_exp": float(np.average(y, weights=wm) / np.average(p, weights=wm)),
        "cal_slope": calibration_slope(y, p, wm),
    })
    return out


def threshold_metrics(y, p, thr) -> dict:
    y, p = np.asarray(y), np.asarray(p)
    flag = p >= thr
    tp, fp = int((flag & (y == 1)).sum()), int((flag & (y == 0)).sum())
    fn, tn = int((~flag & (y == 1)).sum()), int((~flag & (y == 0)).sum())
    sd = lambda a, b: float(a / b) if b else float("nan")
    return {"threshold": float(thr), "alert_rate": float(flag.mean()), "sensitivity": sd(tp, tp + fn),
            "specificity": sd(tn, tn + fp), "ppv": sd(tp, tp + fp), "fnr": sd(fn, tp + fn),
            "fpr": sd(fp, fp + tn)}


def calibration_bins(y, p, n_bins=10) -> pd.DataFrame:
    df = pd.DataFrame({"y": y, "p": p})
    df["bin"] = pd.qcut(df["p"], n_bins, labels=False, duplicates="drop")
    return df.groupby("bin").agg(mean_pred=("p", "mean"), obs_rate=("y", "mean"), n=("y", "size")).reset_index()


def decision_curve(y, p, thresholds=None) -> pd.DataFrame:
    y, p = np.asarray(y), np.asarray(p)
    thresholds = np.round(np.arange(0.02, 0.51, 0.01), 2) if thresholds is None else thresholds
    n, prev = len(y), y.mean()
    rows = []
    for t in thresholds:
        flag = p >= t
        tp = (flag & (y == 1)).sum() / n
        fp = (flag & (y == 0)).sum() / n
        odds = t / (1 - t)
        rows.append({"threshold": t, "net_benefit": tp - fp * odds,
                     "treat_all": prev - (1 - prev) * odds, "treat_none": 0.0})
    return pd.DataFrame(rows)


def cluster_bootstrap(test: pd.DataFrame, preds: dict, y_col: str, B: int = 200, seed: int = 0) -> pd.DataFrame:
    """Person-clustered bootstrap CIs for AUROC/AUPRC/Brier and paired AUROC gain vs the first model."""
    rng = np.random.default_rng(seed)
    ids = test["person_id"].values
    uniq = np.unique(ids)
    pos = pd.Series(np.arange(len(ids))).groupby(ids).apply(np.array).to_dict()
    y = test[y_col].values
    names = list(preds)
    stats = {k: [] for k in names}
    gains = {k: [] for k in names[1:]}
    for _ in range(B):
        idx = np.concatenate([pos[i] for i in rng.choice(uniq, len(uniq), replace=True)])
        yb = y[idx]
        if len(np.unique(yb)) < 2:
            continue
        aucs = {}
        for k in names:
            pb = preds[k][idx]
            aucs[k] = roc_auc_score(yb, pb)
            stats[k].append((aucs[k], average_precision_score(yb, pb), brier_score_loss(yb, pb)))
        for k in names[1:]:
            gains[k].append(aucs[k] - aucs[names[0]])
    rows = []
    for k in names:
        a = np.array(stats[k])
        row = {"model": k}
        for j, m in enumerate(["auroc", "auprc", "brier"]):
            row[f"{m}_lo"], row[f"{m}_hi"] = np.percentile(a[:, j], [2.5, 97.5])
        if k in gains:
            g = np.array(gains[k])
            row["auroc_gain_vs_baseline"] = g.mean()
            row["gain_lo"], row["gain_hi"] = np.percentile(g, [2.5, 97.5])
        rows.append(row)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- fairness
def add_subgroup_columns(test: pd.DataFrame) -> pd.DataFrame:
    t = test.copy()
    if "age" in t:
        t["age_85plus"] = (t["age"] >= 85).astype(int)
    if "dementia_class__cur" in t:
        t["dementia_any"] = (t["dementia_class__cur"] >= 1).astype(int)
    return t


def subgroup_audit(test: pd.DataFrame, p: np.ndarray, y_col: str, thr: float, cols,
                   min_n: int = 100, min_events: int = 15) -> pd.DataFrame:
    t = add_subgroup_columns(test)
    t = t.assign(_p=p)
    rows = []
    for col in cols:
        if col not in t.columns:
            continue
        for level, g in t.groupby(col):
            y = g[y_col].values
            if len(g) < min_n or y.sum() < min_events:
                rows.append({"subgroup": col, "level": str(level), "n": len(g), "events": int(y.sum()),
                             "note": "too small to report"})
                continue
            m = core_metrics(y, g["_p"].values)
            m.update(threshold_metrics(y, g["_p"].values, thr))
            m.update({"subgroup": col, "level": str(level)})
            rows.append(m)
    cols_out = ["subgroup", "level", "n", "events", "prevalence", "auroc", "obs_exp", "cal_slope",
                "alert_rate", "sensitivity", "fnr", "fpr", "ppv", "note"]
    df = pd.DataFrame(rows)
    return df[[c for c in cols_out if c in df.columns]]
