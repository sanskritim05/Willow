"""Turn the long panel into prediction windows and features.

A window is anchored at round t for one person:
    t-1  ->  t   : observed history (features: status at t + change since t-1)
    t+1          : outcome (new help from another person with mobility or self-care)

Only people living in the community and receiving NO help with any of the seven
activities at round t are "at risk". Nothing from round t+1 is ever used as a feature.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .schema import (BINARY_ITEMS, DEMOGRAPHICS, HELP_COLS, MOBILITY, ORDINAL_ITEMS, SELFCARE,
                     STATUS_COMMUNITY, TRACKED_ITEMS)

OPTIONAL_DEMOGRAPHICS = ["low_income"]


def _any_help(df, acts=None):
    cols = HELP_COLS if acts is None else [f"{a}_help" for a in acts]
    return (df[cols].fillna(0).sum(axis=1) > 0).astype(int)


def build_windows(panel: pd.DataFrame) -> pd.DataFrame:
    """Return one row per eligible (person, t) with __prev / __cur item columns and outcomes."""
    p = panel.copy()
    keep = ["person_id", "round", "status"] + TRACKED_ITEMS + HELP_COLS
    extra = [c for c in DEMOGRAPHICS + OPTIONAL_DEMOGRAPHICS + ["race_eth", "weight", "stratum", "psu",
                                                                  "cohort", "source"] if c in p.columns]
    cur = p[keep + [c for c in extra if c not in keep]].copy()
    prev = p[keep].copy()
    prev["round"] = prev["round"] + 1
    nxt = p[["person_id", "round", "status"] + HELP_COLS].copy()
    nxt["round"] = nxt["round"] - 1

    w = cur.merge(prev, on=["person_id", "round"], suffixes=("__cur", "__prev"))
    w = w.merge(nxt.rename(columns={c: f"{c}__next" for c in nxt.columns if c not in ("person_id", "round")}),
                on=["person_id", "round"], how="left")

    cur_help = w[[f"{h}__cur" for h in HELP_COLS]]
    eligible = (
        (w["status__cur"] == STATUS_COMMUNITY)
        & (w["status__prev"] == STATUS_COMMUNITY)
        & cur_help.notna().all(axis=1)
        & (cur_help.sum(axis=1) == 0)
        & w["status__next"].notna()
        & (w["status__next"] != "nonresponse")
    )
    w = w[eligible].copy()

    nxt_help = w[[f"{h}__next" for h in HELP_COLS]].rename(columns=lambda c: c.replace("__next", ""))
    in_comm = (w["status__next"] == STATUS_COMMUNITY)
    w["exit_next"] = w["status__next"]
    w["y_any"] = np.where(in_comm, _any_help(nxt_help), np.nan)
    w["y_mobility"] = np.where(in_comm, _any_help(nxt_help, MOBILITY), np.nan)
    w["y_selfcare"] = np.where(in_comm, _any_help(nxt_help, SELFCARE), np.nan)
    # composite for sensitivity analysis: new help OR moved to care OR died
    w["y_composite"] = np.where(in_comm, w["y_any"], 1.0)
    # calendar-period flags (known in advance, not leakage): NHATS round 10 = 2020, 11 = 2021
    w["covid_change"] = w["round"].isin([10, 11]).astype(int)     # t-1 -> t change spans the pandemic
    w["covid_outcome"] = w["round"].isin([9, 10]).astype(int)     # outcome year t+1 is 2020/2021
    w["prev_any_help"] = (w[[f"{h}__prev" for h in HELP_COLS]].fillna(0).sum(axis=1) > 0).astype(int)
    w = w.drop(columns=[c for c in w.columns if c.endswith("__next")])
    for c in ["age", "female", "lives_alone", "proxy", "low_income", "race_eth", "weight", "cohort", "source",
              "stratum", "psu"]:
        if f"{c}__cur" in w.columns:
            w = w.rename(columns={f"{c}__cur": c})
        if f"{c}__prev" in w.columns and c != "proxy":
            w = w.drop(columns=f"{c}__prev")
    if "proxy__prev" in w.columns:
        w = w.drop(columns="proxy__prev")
    return w.reset_index(drop=True)


def status_features(w: pd.DataFrame) -> pd.DataFrame:
    X = pd.DataFrame(index=w.index)
    for it in TRACKED_ITEMS:
        X[f"cur_{it}"] = w[f"{it}__cur"]
    for d in DEMOGRAPHICS + OPTIONAL_DEMOGRAPHICS:
        if d in w.columns:
            X[d] = w[d]
    X["covid_change"] = w["covid_change"]      # calendar flags go in every model, baseline included
    X["covid_outcome"] = w["covid_outcome"]
    return X


def change_features(w: pd.DataFrame) -> pd.DataFrame:
    X = status_features(w)
    for it in ORDINAL_ITEMS:
        X[f"d_{it}"] = w[f"{it}__cur"] - w[f"{it}__prev"]
    for it in BINARY_ITEMS:
        X[f"new_{it}"] = ((w[f"{it}__cur"] == 1) & (w[f"{it}__prev"] == 0)).astype(float)
        X.loc[w[f"{it}__cur"].isna() | w[f"{it}__prev"].isna(), f"new_{it}"] = np.nan
    diff_d = X[[c for c in X.columns if c.startswith("d_") and c.endswith("_diff")]]
    X["n_worse_difficulty"] = (diff_d > 0).sum(axis=1)
    X["n_new_devices"] = X[[c for c in X.columns if c.startswith("new_") and c.endswith("_device")]].sum(axis=1)
    X["n_new_doing_less"] = X[[c for c in X.columns if c.startswith("new_") and c.endswith("_less")]].sum(axis=1)
    X["n_new_went_without"] = X[[c for c in X.columns if c.startswith("new_") and c.endswith("_wout")]].sum(axis=1)
    X["prev_any_help"] = w["prev_any_help"]
    return X


FEATURE_SETS = {"status": status_features, "change": change_features}


def make_X(w: pd.DataFrame, feature_set: str = "change") -> pd.DataFrame:
    return FEATURE_SETS[feature_set](w).astype(float)


def counterfactual(w: pd.DataFrame, items: list[str]) -> pd.DataFrame:
    """Copy of windows where the given items did NOT change between t-1 and t."""
    cf = w.copy()
    for it in items:
        cf[f"{it}__cur"] = cf[f"{it}__prev"]
    return cf
