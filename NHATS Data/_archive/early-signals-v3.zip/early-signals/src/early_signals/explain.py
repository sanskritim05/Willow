"""Explanations in terms of *changes*, not model internals.

For each person-window and each change group (e.g. "Going out less often"), we ask:
what would the predicted risk be if that change had NOT happened between t-1 and t?
    contribution = risk(actual) - risk(counterfactual: group items held at t-1 values)
This works for any model, is phrased the way a caregiver or clinician thinks, and only
uses information the person already reported. Contributions are not additive (unlike
SHAP values); optional SHAP output is provided for the paper when `shap` is installed.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .features import counterfactual, make_X
from .schema import CHANGE_GROUPS


def _changed(w: pd.DataFrame, items) -> np.ndarray:
    m = np.zeros(len(w), dtype=bool)
    for it in items:
        a, b = w[f"{it}__cur"].values, w[f"{it}__prev"].values
        m |= ~np.isnan(a) & ~np.isnan(b) & (a != b)
    return m


def change_contributions(model, feature_set: str, w: pd.DataFrame) -> pd.DataFrame:
    """Long table: row index, group, changed?, contribution (risk points, 0-1 scale)."""
    base = model.predict_proba(make_X(w, feature_set))[:, 1]
    out = []
    for group, items in CHANGE_GROUPS.items():
        changed = _changed(w, items)
        contrib = np.zeros(len(w))
        if changed.any():
            sub = w[changed]
            cf = model.predict_proba(make_X(counterfactual(sub, items), feature_set))[:, 1]
            contrib[changed] = base[changed] - cf
        out.append(pd.DataFrame({"row": w.index, "group": group, "changed": changed, "contribution": contrib}))
    df = pd.concat(out, ignore_index=True)
    df["risk"] = np.tile(base, len(CHANGE_GROUPS))
    return df


def global_change_importance(contrib: pd.DataFrame) -> pd.DataFrame:
    c = contrib[contrib.changed]
    g = c.groupby("group").agg(n_changed=("contribution", "size"),
                               mean_contribution=("contribution", "mean"),
                               mean_abs_contribution=("contribution", lambda x: np.abs(x).mean()))
    return g.sort_values("mean_abs_contribution", ascending=False).reset_index()


def shap_summary(model, X: pd.DataFrame, max_rows: int = 2000):
    """Mean |SHAP| per feature for tree models, if the shap package is available."""
    try:
        import shap  # type: ignore
    except Exception:
        return None
    Xs = X.sample(min(max_rows, len(X)), random_state=0)
    est = model[-1] if hasattr(model, "steps") else model
    Xt = model[:-1].transform(Xs) if hasattr(model, "steps") else Xs
    try:
        sv = shap.TreeExplainer(est).shap_values(Xt)
    except Exception:
        return None
    sv = sv[1] if isinstance(sv, list) else sv
    names = list(X.columns) + [f"missing_{i}" for i in range(np.asarray(Xt).shape[1] - X.shape[1])]
    return (pd.DataFrame({"feature": names, "mean_abs_shap": np.abs(sv).mean(axis=0)})
            .sort_values("mean_abs_shap", ascending=False))
