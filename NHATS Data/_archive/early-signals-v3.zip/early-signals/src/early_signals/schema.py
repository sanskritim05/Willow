"""Canonical long-format schema shared by the synthetic generator and the NHATS loader.

One row per person per round. Every downstream step (features, models, app export)
only sees these names, so swapping synthetic data for real NHATS data is a loader change.
"""

MOBILITY = ["go_outside", "get_around_inside", "get_out_of_bed"]
SELFCARE = ["eating", "bathing", "toileting", "dressing"]
ACTIVITIES = MOBILITY + SELFCARE

DEVICE_ACTS = list(ACTIVITIES)  # NHATS derived device-use measures exist for all seven
# "less often than a year ago" (NHATS *yrgo items)
LESS_ACTS = ["go_outside", "get_around_inside", "bathing", "dressing"]
# "went without / stayed in because no one to help or too difficult" (NHATS *wout items)
WOUT_ACTS = ["go_outside", "get_around_inside", "get_out_of_bed", "eating", "bathing", "dressing"]

HELP_COLS = [f"{a}_help" for a in ACTIVITIES]
DIFF_COLS = [f"{a}_diff" for a in ACTIVITIES]
DEVICE_COLS = [f"{a}_device" for a in DEVICE_ACTS]
LESS_COLS = [f"{a}_less" for a in LESS_ACTS]
WOUT_COLS = [f"{a}_wout" for a in WOUT_ACTS]

# health context items (ordinal/continuous or binary)
HEALTH_BINARY = ["fell_last_year", "pain_limits", "hospital_stay"]
HEALTH_ORDINAL = ["self_rated_health", "phq2", "dementia_class"]

ORDINAL_ITEMS = DIFF_COLS + ["go_out_freq"] + HEALTH_ORDINAL
BINARY_ITEMS = DEVICE_COLS + LESS_COLS + WOUT_COLS + HEALTH_BINARY

# items tracked over time (everything the timeline shows, except help which defines the outcome)
TRACKED_ITEMS = ORDINAL_ITEMS + BINARY_ITEMS

DEMOGRAPHICS = ["age", "female", "lives_alone", "proxy"]
SUBGROUP_COLS = ["race_eth", "female", "low_income", "lives_alone", "proxy", "dementia_any", "age_85plus"]

STATUS_COMMUNITY = "community"
STATUS_VALUES = ["community", "residential_care", "nursing_home", "deceased", "nonresponse"]

# Groups of items that form one human-readable "change" for explanations.
CHANGE_GROUPS = {
    "Going out less often": ["go_out_freq", "go_outside_less", "go_outside_wout"],
    "Harder to go outside": ["go_outside_diff", "go_outside_device"],
    "Harder to move around inside": ["get_around_inside_diff", "get_around_inside_device", "get_around_inside_less",
                                     "get_around_inside_wout"],
    "Harder to get out of bed": ["get_out_of_bed_diff", "get_out_of_bed_device", "get_out_of_bed_wout"],
    "Changes in bathing": ["bathing_diff", "bathing_device", "bathing_less", "bathing_wout"],
    "Changes in dressing": ["dressing_diff", "dressing_device", "dressing_less", "dressing_wout"],
    "Harder to use the toilet": ["toileting_diff", "toileting_device"],
    "Harder to eat independently": ["eating_diff", "eating_device", "eating_wout"],
    "Recent fall": ["fell_last_year"],
    "Worse self-rated health": ["self_rated_health"],
    "More depressive symptoms": ["phq2"],
    "Cognitive change": ["dementia_class"],
    "Pain limiting activity": ["pain_limits"],
    "Hospital stay": ["hospital_stay"],
}

ITEM_LABELS = {
    "go_out_freq": "How often goes outside (0 = every day, 4 = never)",
    "self_rated_health": "Self-rated health (1 excellent - 5 poor)",
    "phq2": "Depressive symptoms (PHQ-2, 0-6)",
    "dementia_class": "Dementia classification (0 none, 1 possible, 2 probable)",
    "fell_last_year": "Recent fall (NHATS: fell in the last month)",
    "pain_limits": "Pain limits activities",
    "hospital_stay": "Hospital stay in the last year",
}
for a in ACTIVITIES:
    nice = a.replace("_", " ")
    ITEM_LABELS[f"{a}_diff"] = f"Difficulty {nice} alone (0-3)"
    ITEM_LABELS[f"{a}_help"] = f"Help from a person: {nice}"
for a in DEVICE_ACTS:
    ITEM_LABELS[f"{a}_device"] = f"Uses a device for {a.replace('_', ' ')}"
for a in LESS_ACTS:
    ITEM_LABELS[f"{a}_less"] = f"Does {a.replace('_', ' ')} less often than a year ago"
for a in WOUT_ACTS:
    ITEM_LABELS[f"{a}_wout"] = f"Went without {a.replace('_', ' ')} (no help / too hard)"
