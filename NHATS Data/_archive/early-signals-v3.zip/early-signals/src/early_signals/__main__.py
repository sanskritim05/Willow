"""CLI:  python -m early_signals run --source synthetic
        python -m early_signals run --source nhats --nhats-dir /path/to/NHATS
        python -m early_signals inspect --nhats-dir /path/to/NHATS"""
import argparse


def main():
    ap = argparse.ArgumentParser(prog="early_signals")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run the full pipeline")
    r.add_argument("--source", choices=["synthetic", "nhats"], default="synthetic")
    r.add_argument("--nhats-dir")
    r.add_argument("--out", default="outputs")
    r.add_argument("--outcome", default="y_any", choices=["y_any", "y_mobility", "y_selfcare", "y_composite"])
    r.add_argument("--split-round", type=int)
    r.add_argument("--bootstrap", type=int, default=200)
    r.add_argument("--scale", type=float, default=1.0, help="synthetic sample size multiplier")
    d = sub.add_parser("describe", help="aggregate sanity-check tables (safe to share)")
    d.add_argument("--source", choices=["synthetic", "nhats"], default="nhats")
    d.add_argument("--nhats-dir")
    dc = sub.add_parser("dementia-check", help="compare dementia classification with NHATS published counts")
    dc.add_argument("--nhats-dir", required=True)
    i = sub.add_parser("inspect", help="check the variable map against your NHATS files")
    i.add_argument("--nhats-dir", required=True)
    a = ap.parse_args()
    if a.cmd == "run":
        from .pipeline import run
        run(a.source, a.nhats_dir, a.out, a.outcome, a.split_round, bootstrap=a.bootstrap, scale=a.scale)
    elif a.cmd == "dementia-check":
        from .dementia import check
        res = check(a.nhats_dir)
        print(res.to_string(index=False))
        known = res.dropna(subset=["match"])
        print(f"\n{int(known.match.sum())}/{len(known)} published counts matched exactly")
    elif a.cmd == "describe":
        from .describe import describe  # pandas-only path: no scikit-learn needed
        if a.source == "synthetic":
            from .synth import generate
            panel = generate()
        else:
            from .nhats_loader import load_panel
            panel = load_panel(a.nhats_dir)
        print(describe(panel))
    else:
        from .nhats_loader import inspect
        df = inspect(a.nhats_dir)
        miss = df[~df.found]
        print(df.groupby("round").found.mean().rename("share_found").to_string())
        print(f"\n{len(miss)} missing variable(s):")
        print(miss.to_string(index=False) if len(miss) else "none")


if __name__ == "__main__":
    main()
