"""Explanations in terms of *changes*, not model internals.

For each person-window and each change group (e.g. "Going out less often"), we ask:
what would the predicted risk be if that change had NOT happened between t-1 and t?
    contribution = risk(actual) - risk(counterfactual: group items held at t-1 values)
This works for any model, is phrased the way a caregiver or clinician thinks, and only
uses information the person already reported. Contributions are not additive (unlike
SHAP values); optional SHAP output is provided for the paper when `shap` is installed.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .features import counterfactual, make_X
from .schema import CHANGE_GROUPS


def _changed(w: pd.DataFrame, items) -> np.ndarray:
    m = np.zeros(len(w), dtype=bool)
    for it in items:
        a, b = w[f"{it}__cur"].values, w[f"{it}__prev"].values
        m |= ~np.isnan(a) & ~np.isnan(b) & (a != b)
    return m


def _direction(w: pd.DataFrame, items) -> np.ndarray:
    """+1 if any item got worse (all items are coded so higher = worse), -1 if only improvements, 0 none."""
    worse = np.zeros(len(w), dtype=bool)
    better = np.zeros(len(w), dtype=bool)
    for it in items:
        a, b = w[f"{it}__cur"].values, w[f"{it}__prev"].values
        ok = ~np.isnan(a) & ~np.isnan(b)
        worse |= ok & (a > b)
        better |= ok & (a < b)
    return np.where(worse, 1, np.where(better, -1, 0))


def change_contributions(model, feature_set: str, w: pd.DataFrame) -> pd.DataFrame:
    """Long table: row index, group, changed?, contribution (risk points, 0-1 scale)."""
    base = model.predict_proba(make_X(w, feature_set))[:, 1]
    out = []
    for group, items in CHANGE_GROUPS.items():
        changed = _changed(w, items)
        contrib = np.zeros(len(w))
        if changed.any():
            sub = w[changed]
            cf = model.predict_proba(make_X(counterfactual(sub, items), feature_set))[:, 1]
            contrib[changed] = base[changed] - cf
        out.append(pd.DataFrame({"row": w.index, "group": group, "changed": changed,
                                 "direction": _direction(w, items), "contribution": contrib}))
    df = pd.concat(out, ignore_index=True)
    df["risk"] = np.tile(base, len(CHANGE_GROUPS))
    return df


def global_change_importance(contrib: pd.DataFrame, y=None) -> pd.DataFrame:
    """Direction-aware summary: for each change, among people whose situation got WORSE
    (and separately, got better), the average shift in predicted risk and the observed
    rate of new help. Mixing directions would let improvements cancel out declines."""
    rows = []
    for (group, d), c in contrib[contrib.changed & (contrib.direction != 0)].groupby(["group", "direction"]):
        r = {"group": group, "direction": "worse" if d == 1 else "better", "n": len(c),
             "mean_contribution": c.contribution.mean(),
             "median_contribution": c.contribution.median(),
             "share_raised_risk": (c.contribution > 0).mean()}
        if y is not None:
            r["observed_new_help"] = float(np.nanmean(np.asarray(y)[c.row.values]))
        rows.append(r)
    if y is not None:  # reference row: people with no decline in any tracked area
        anyworse = contrib[contrib.direction == 1].groupby("row").size()
        rows_all = contrib.row.unique()
        none = np.setdiff1d(rows_all, anyworse.index.values)
        rows.append({"group": "(no decline in any area)", "direction": "none", "n": len(none),
                     "mean_contribution": np.nan, "median_contribution": np.nan, "share_raised_risk": np.nan,
                     "observed_new_help": float(np.nanmean(np.asarray(y)[none])) if len(none) else np.nan})
    out = pd.DataFrame(rows)
    order = {"worse": 0, "none": 1, "better": 2}
    out["_o"] = out.direction.map(order)
    return out.sort_values(["_o", "mean_contribution"], ascending=[True, False]).drop(columns="_o").reset_index(drop=True)


def shap_summary(model, X: pd.DataFrame, max_rows: int = 2000):
    """Mean |SHAP| per feature for tree models, if the shap package is available."""
    try:
        import shap  # type: ignore
    except Exception:
        return None
    Xs = X.sample(min(max_rows, len(X)), random_state=0)
    est = model[-1] if hasattr(model, "steps") else model
    Xt = model[:-1].transform(Xs) if hasattr(model, "steps") else Xs
    try:
        sv = shap.TreeExplainer(est).shap_values(Xt)
    except Exception:
        return None
    sv = sv[1] if isinstance(sv, list) else sv
    names = list(X.columns) + [f"missing_{i}" for i in range(np.asarray(Xt).shape[1] - X.shape[1])]
    return (pd.DataFrame({"feature": names, "mean_abs_shap": np.abs(sv).mean(axis=0)})
            .sort_values("mean_abs_shap", ascending=False))
