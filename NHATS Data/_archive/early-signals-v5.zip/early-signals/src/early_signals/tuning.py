"""Expanded model: feature-set and hyperparameter selection on TRAINING data only, then one test run.

Protocol (report it this way in the paper):
  1. Candidates = feature sets {v1 change, + expanded measures, + two-year trends}
     x model families {penalized logistic, gradient-boosted trees}, plus a logistic+trees average.
  2. Each candidate is scored by 5-fold person-grouped cross-validation on the training windows
     (out-of-fold AUROC). Trees use early stopping inside each fold; the number of trees for the
     final fit is the median of the fold optima.
  3. The candidate with the best out-of-fold AUROC is selected; a Platt recalibration is fit on
     its out-of-fold predictions (training data only).
  4. The selected model is refit on all training windows and applied ONCE to the locked test set.
The pre-specified v1 model remains the primary analysis; this is a secondary, exploratory analysis.
"""
from __future__ import annotations

import json
import os
import time

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from . import evaluate as ev
from .features import make_X

try:
    from xgboost import XGBClassifier  # type: ignore
    HAS_XGB = True
except Exception:  # pragma: no cover
    from sklearn.ensemble import HistGradientBoostingClassifier
    HAS_XGB = False

FEATURE_SETS = ["change", "change_plus", "change_plus_2yr"]
LOGIT_C = [0.02, 0.1, 0.5]


def _xgb_space(n, seed):
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(n):
        out.append({"max_depth": int(rng.choice([2, 3, 4, 5, 6])),
                    "learning_rate": float(rng.choice([0.02, 0.03, 0.05, 0.08])),
                    "min_child_weight": float(rng.choice([1, 5, 10, 20, 40])),
                    "subsample": float(rng.choice([0.6, 0.8, 1.0])),
                    "colsample_bytree": float(rng.choice([0.3, 0.5, 0.7, 0.9])),
                    "reg_lambda": float(rng.choice([0.5, 1, 5, 10])),
                    "gamma": float(rng.choice([0, 0.5, 1]))})
    return out


def _logit_model(C):
    return make_pipeline(SimpleImputer(strategy="median", add_indicator=True), StandardScaler(),
                         LogisticRegression(C=C, max_iter=3000))


def _tree_model(params, n_estimators, seed, early=None):
    if HAS_XGB:
        kw = dict(n_estimators=n_estimators, eval_metric="logloss", tree_method="hist", random_state=seed,
                  n_jobs=-1, **params)
        if early:
            kw["early_stopping_rounds"] = early
        return XGBClassifier(**kw)
    return HistGradientBoostingClassifier(learning_rate=params["learning_rate"], max_depth=params["max_depth"],
                                          min_samples_leaf=int(max(20, params["min_child_weight"] * 4)),
                                          l2_regularization=params["reg_lambda"], max_iter=n_estimators,
                                          early_stopping=True, validation_fraction=0.15, random_state=seed)


def _cv_logit(X, y, groups, folds, C):
    oof = np.zeros(len(y))
    for tr, va in folds:
        m = _logit_model(C).fit(X.iloc[tr], y[tr])
        oof[va] = m.predict_proba(X.iloc[va])[:, 1]
    return oof


def _cv_tree(X, y, folds, params, seed):
    oof, iters = np.zeros(len(y)), []
    for tr, va in folds:
        if HAS_XGB:
            m = _tree_model(params, 3000, seed, early=100)
            m.fit(X.iloc[tr], y[tr], eval_set=[(X.iloc[va], y[va])], verbose=False)
            iters.append(int(m.best_iteration) + 1)
        else:
            m = _tree_model(params, 1500, seed).fit(X.iloc[tr], y[tr])
            iters.append(int(m.n_iter_))
        oof[va] = m.predict_proba(X.iloc[va])[:, 1]
    return oof, int(np.median(iters))


class Platt:
    def fit(self, p, y):
        self.m = LogisticRegression(C=1e6, max_iter=1000).fit(ev._logit(p).reshape(-1, 1), y)
        return self

    def __call__(self, p):
        return self.m.predict_proba(ev._logit(p).reshape(-1, 1))[:, 1]


class FittedCandidate:
    """Final fitted model (possibly an average of logistic + trees) with Platt recalibration."""

    def __init__(self, fset, parts, calib):
        self.fset, self.parts, self.calib = fset, parts, calib

    def raw(self, X):
        return np.mean([m.predict_proba(X)[:, 1] for m in self.parts], axis=0)

    def predict_proba(self, X):
        p = self.calib(self.raw(X))
        return np.column_stack([1 - p, p])


def select_and_fit(train, outcome, n_trees_configs=12, seed=0, log=print):
    y = train[outcome].astype(int).values
    groups = train["person_id"].values
    folds = list(GroupKFold(n_splits=5).split(train, y, groups))
    rows, best = [], {}
    for fset in FEATURE_SETS:
        X = make_X(train, fset)
        t0 = time.time()
        for C in LOGIT_C:
            oof = _cv_logit(X, y, groups, folds, C)
            rows.append({"feature_set": fset, "family": "logistic", "config": json.dumps({"C": C}),
                         "cv_auroc": roc_auc_score(y, oof), "cv_logloss": log_loss(y, np.clip(oof, 1e-6, 1 - 1e-6))})
            if rows[-1]["cv_auroc"] > best.get((fset, "logistic"), ({}, -1, None))[1]:
                best[(fset, "logistic")] = ({"C": C}, rows[-1]["cv_auroc"], oof)
        for params in _xgb_space(n_trees_configs, seed):
            oof, n_est = _cv_tree(X, y, folds, params, seed)
            cfg = {**params, "n_estimators": n_est}
            rows.append({"feature_set": fset, "family": "trees", "config": json.dumps(cfg),
                         "cv_auroc": roc_auc_score(y, oof), "cv_logloss": log_loss(y, np.clip(oof, 1e-6, 1 - 1e-6))})
            if rows[-1]["cv_auroc"] > best.get((fset, "trees"), ({}, -1, None))[1]:
                best[(fset, "trees")] = (cfg, rows[-1]["cv_auroc"], oof)
        # ensemble of the best logistic and best trees on this feature set
        ens = (best[(fset, "logistic")][2] + best[(fset, "trees")][2]) / 2
        rows.append({"feature_set": fset, "family": "logistic+trees", "config": "average of best of each",
                     "cv_auroc": roc_auc_score(y, ens), "cv_logloss": log_loss(y, np.clip(ens, 1e-6, 1 - 1e-6))})
        best[(fset, "logistic+trees")] = (None, rows[-1]["cv_auroc"], ens)
        log(f"[tune] {fset:16s} best CV AUROC  logistic {best[(fset, 'logistic')][1]:.3f}  "
            f"trees {best[(fset, 'trees')][1]:.3f}  average {best[(fset, 'logistic+trees')][1]:.3f}  "
            f"({time.time() - t0:.0f}s)")
    cv = pd.DataFrame(rows).sort_values("cv_auroc", ascending=False)
    (fset, family), (cfg, score, oof) = max(best.items(), key=lambda kv: kv[1][1])
    calib = Platt().fit(oof, y)
    X = make_X(train, fset)
    parts = []
    if family in ("logistic", "logistic+trees"):
        parts.append(_logit_model(best[(fset, "logistic")][0]["C"]).fit(X, y))
    if family in ("trees", "logistic+trees"):
        tc = dict(best[(fset, "trees")][0])
        n_est = tc.pop("n_estimators")
        parts.append(_tree_model(tc, n_est, seed).fit(X, y))
    chosen = {"feature_set": fset, "family": family, "cv_auroc": score,
              "logistic": best[(fset, "logistic")][0] if family != "trees" else None,
              "trees": best[(fset, "trees")][0] if family != "logistic" else None,
              "cv_calibration_slope_before_recal": ev.calibration_slope(y, oof)}
    log(f"[tune] selected: {family} on '{fset}' (CV AUROC {score:.3f}); Platt recalibration fit on OOF predictions")
    return FittedCandidate(fset, parts, calib), chosen, cv


def race_calibration_gap(test, p, outcome, B=500, seed=0):
    """O/E among Black + Hispanic vs White, with a person-clustered bootstrap CI for the difference."""
    t = test.assign(_p=p)
    minority = t.race_eth.isin(["black", "hispanic"]).values
    white = (t.race_eth == "white").values
    rng = np.random.default_rng(seed)
    ids = t.person_id.values
    pos = pd.Series(np.arange(len(t))).groupby(ids).apply(np.array).to_dict()
    uniq = np.array(list(pos))
    y, pp = t[outcome].values, t._p.values
    oe = lambda idx, m: y[idx][m[idx]].mean() / pp[idx][m[idx]].mean()
    base = np.arange(len(t))
    point = (oe(base, minority), oe(base, white))
    diffs, mins, whs = [], [], []
    for _ in range(B):
        idx = np.concatenate([pos[i] for i in rng.choice(uniq, len(uniq), replace=True)])
        a, b = oe(idx, minority), oe(idx, white)
        mins.append(a); whs.append(b); diffs.append(a - b)
    q = lambda v: np.percentile(v, [2.5, 97.5])
    return {"oe_black_hispanic": point[0], "oe_black_hispanic_ci": list(q(mins)),
            "oe_white": point[1], "oe_white_ci": list(q(whs)),
            "difference": point[0] - point[1], "difference_ci": list(q(diffs)),
            "n_black_hispanic": int(minority.sum()), "n_white": int(white.sum())}


def repeated_splits(analytic, outcome, split_round, chosen, n=10, log=print):
    """Robustness: re-draw the held-out people n times; refit v1 baseline, v1 primary, and the selected
    expanded configuration (hyperparameters fixed, no re-tuning); record test AUROCs."""
    from .models import model_specs
    specs = model_specs()
    names = list(specs)
    rows = []
    for s in range(1, n + 1):
        tr, te = ev.temporal_person_split(analytic, split_round, seed=100 + s)
        y_tr, y_te = tr[outcome].values, te[outcome].values
        r = {"split_seed": 100 + s, "n_test": len(te)}
        for nm in (names[0], names[-1]):
            fset, fac = specs[nm]
            m = fac().fit(make_X(tr, fset), y_tr)
            r[nm] = roc_auc_score(y_te, m.predict_proba(make_X(te, fset))[:, 1])
        fset = chosen["feature_set"]
        Xtr, Xte = make_X(tr, fset), make_X(te, fset)
        ps = []
        if chosen.get("logistic"):
            ps.append(_logit_model(chosen["logistic"]["C"]).fit(Xtr, y_tr).predict_proba(Xte)[:, 1])
        if chosen.get("trees"):
            tc = dict(chosen["trees"]); n_est = tc.pop("n_estimators")
            ps.append(_tree_model(tc, n_est, 0).fit(Xtr, y_tr).predict_proba(Xte)[:, 1])
        r["expanded"] = roc_auc_score(y_te, np.mean(ps, axis=0))
        rows.append(r)
        log(f"[repeat {s}/{n}] baseline {r[names[0]]:.3f}  v1 {r[names[-1]]:.3f}  expanded {r['expanded']:.3f}")
    return pd.DataFrame(rows)


def run_expanded(analytic, train, test, outcome, out_dir, preds_v1, split_round, primary_name,
                 n_trees_configs=12, repeats=10, seed=0, log=print):
    from .explain import change_contributions, global_change_importance, shap_summary
    model, chosen, cv = select_and_fit(train, outcome, n_trees_configs, seed, log)
    cv.to_csv(os.path.join(out_dir, "expanded_cv_results.csv"), index=False)
    X_te = make_X(test, model.fset)
    p = model.predict_proba(X_te)[:, 1]            # the ONE use of the test set for this analysis
    y = test[outcome].values
    thr = float(np.quantile(model.predict_proba(make_X(train, model.fset))[:, 1], 0.8))
    res = {"model": "expanded (CV-selected)", "features": model.fset, **ev.core_metrics(y, p),
           **{f"weighted_{k}": v for k, v in ev.core_metrics(y, p, test["weight"].values).items()
              if k in ("auroc", "auprc")},
           **ev.threshold_metrics(y, p, thr)}
    names = list(preds_v1)
    boot = ev.cluster_bootstrap(test, {names[0]: preds_v1[names[0]], primary_name: preds_v1[primary_name],
                                       "expanded": p}, outcome, B=500, seed=seed)
    # paired gain of expanded over the v1 primary model
    boot2 = ev.cluster_bootstrap(test, {primary_name: preds_v1[primary_name], "expanded": p}, outcome, B=500, seed=seed)
    fair = ev.subgroup_audit(test, p, outcome, thr, ["race_eth", "female", "medicaid", "lives_alone", "proxy",
                                                        "dementia_any", "age_85plus"])
    gap_exp = race_calibration_gap(test, p, outcome)
    gap_v1 = race_calibration_gap(test, preds_v1[primary_name], outcome)
    tr = test.reset_index(drop=True)
    contrib = change_contributions(model, model.fset, tr)
    imp = global_change_importance(contrib, tr[outcome].values)
    shap_df = None
    trees = [m for m in model.parts if not hasattr(m, "steps")]
    if trees:
        shap_df = shap_summary(trees[0], X_te)
    reps = repeated_splits(analytic, outcome, split_round, chosen, n=repeats, log=log) if repeats else None

    for nm, df in {"expanded_metrics": pd.DataFrame([res]), "expanded_bootstrap": boot,
                   "expanded_vs_v1": boot2, "expanded_subgroups": fair, "expanded_change_importance": imp,
                   "repeated_splits": reps, "expanded_shap": shap_df}.items():
        if df is not None:
            df.to_csv(os.path.join(out_dir, f"{nm}.csv"), index=False)
    with open(os.path.join(out_dir, "expanded_selection.json"), "w") as f:
        json.dump({"chosen": chosen, "race_calibration_expanded": gap_exp, "race_calibration_v1": gap_v1},
                  f, indent=1, default=float)
    write_expanded_report(out_dir, res, boot, boot2, chosen, cv, fair, imp, reps, gap_v1, gap_exp, shap_df,
                          names[0], primary_name)
    log(f"[expanded] test AUROC {res['auroc']:.3f}  AUPRC {res['auprc']:.3f}  O/E {res['obs_exp']:.2f}  "
        f"slope {res['cal_slope']:.2f}  sens@20% {res['sensitivity']:.2f}")
    return res


def write_expanded_report(out_dir, res, boot, boot2, chosen, cv, fair, imp, reps, gap_v1, gap_exp, shap_df,
                          base_name, primary_name):
    b = boot.set_index("model")
    b2 = boot2.set_index("model")
    L = ["# Early Signals — expanded model (secondary analysis)", "",
         "Feature set and hyperparameters chosen by 5-fold person-grouped cross-validation on the TRAINING "
         "windows only; the locked test set was used once. The pre-specified v1 model remains the primary result.", "",
         f"**Selected:** {chosen['family']} on feature set `{chosen['feature_set']}` "
         f"(CV AUROC {chosen['cv_auroc']:.3f}); Platt-recalibrated on out-of-fold predictions.", "",
         "## Test-set performance", "",
         "| Model | AUROC (95% CI) | AUPRC | Brier | O/E | Cal. slope | Sensitivity | PPV | Weighted AUROC |",
         "|---|---|---|---|---|---|---|---|---|",
         f"| expanded | {res['auroc']:.3f} ({b.loc['expanded','auroc_lo']:.3f}–{b.loc['expanded','auroc_hi']:.3f}) | "
         f"{res['auprc']:.3f} | {res['brier']:.3f} | {res['obs_exp']:.2f} | {res['cal_slope']:.2f} | "
         f"{res['sensitivity']:.2f} | {res['ppv']:.2f} | {res.get('weighted_auroc', float('nan')):.3f} |", "",
         f"- Gain over status-only baseline: **{b.loc['expanded','auroc_gain_vs_baseline']:+.3f}** "
         f"({b.loc['expanded','gain_lo']:+.3f} to {b.loc['expanded','gain_hi']:+.3f})",
         f"- Gain over v1 primary ({primary_name}): **{b2.loc['expanded','auroc_gain_vs_baseline']:+.3f}** "
         f"({b2.loc['expanded','gain_lo']:+.3f} to {b2.loc['expanded','gain_hi']:+.3f})", "",
         "## Cross-validation (training data only): best configuration per feature set and family", "",
         "| Feature set | Family | CV AUROC | CV log-loss |", "|---|---|---|---|"]
    top = cv.sort_values("cv_auroc", ascending=False).groupby(["feature_set", "family"]).head(1)
    for r in top.sort_values("cv_auroc", ascending=False).itertuples():
        L.append(f"| {r.feature_set} | {r.family} | {r.cv_auroc:.3f} | {r.cv_logloss:.4f} |")
    if reps is not None and len(reps):
        cols = [c for c in reps.columns if c not in ("split_seed", "n_test")]
        L += ["", f"## Robustness: {len(reps)} re-drawn test sets (fixed hyperparameters)", "",
              "| Model | Mean AUROC | Min | Max |", "|---|---|---|---|"]
        for c in cols:
            L.append(f"| {c} | {reps[c].mean():.3f} | {reps[c].min():.3f} | {reps[c].max():.3f} |")
        g1 = reps[cols[1]] - reps[cols[0]]
        g2 = reps["expanded"] - reps[cols[1]]
        L += ["", f"- v1 change model beat the baseline in {int((g1 > 0).sum())}/{len(reps)} splits "
              f"(mean gain {g1.mean():+.3f}).",
              f"- Expanded model beat v1 in {int((g2 > 0).sum())}/{len(reps)} splits (mean gain {g2.mean():+.3f})."]
    L += ["", "## Race/ethnicity calibration (pooled)", "",
          "O/E > 1 = model under-estimates risk. Difference = O/E(Black+Hispanic) − O/E(White), person-clustered bootstrap.", "",
          "| Model | O/E Black+Hispanic | O/E White | Difference (95% CI) |", "|---|---|---|---|"]
    for nm, g in (("v1 primary", gap_v1), ("expanded", gap_exp)):
        L.append(f"| {nm} | {g['oe_black_hispanic']:.2f} ({g['oe_black_hispanic_ci'][0]:.2f}–{g['oe_black_hispanic_ci'][1]:.2f}) | "
                 f"{g['oe_white']:.2f} ({g['oe_white_ci'][0]:.2f}–{g['oe_white_ci'][1]:.2f}) | "
                 f"{g['difference']:+.2f} ({g['difference_ci'][0]:+.2f} to {g['difference_ci'][1]:+.2f}) |")
    L += ["", "## Subgroups (expanded model)", "",
          "| Subgroup | Level | n | Prev. | AUROC (95% CI) | O/E (95% CI) | Sensitivity (95% CI) | FPR | Alert rate |",
          "|---|---|---|---|---|---|---|---|---|"]
    for r in fair.itertuples():
        if hasattr(r, "auroc") and r.auroc == r.auroc:
            L.append(f"| {r.subgroup} | {r.level} | {r.n} | {r.prevalence:.3f} | {r.auroc:.3f} ({r.auroc_lo:.3f}–{r.auroc_hi:.3f}) | "
                     f"{r.obs_exp:.2f} ({r.obs_exp_lo:.2f}–{r.obs_exp_hi:.2f}) | {r.sensitivity:.2f} "
                     f"({r.sensitivity_lo:.2f}–{r.sensitivity_hi:.2f}) | {r.fpr:.2f} | {r.alert_rate:.2f} |")
        else:
            L.append(f"| {r.subgroup} | {r.level} | {r.n} | — | too few events to report | | | | |")
    L += ["", "## Which declines drive risk (expanded model)", "",
          "| Change | Direction | People | Mean contribution (pts) | Share raised risk | Observed new help |",
          "|---|---|---|---|---|---|"]
    for r in imp.itertuples():
        mc = "—" if r.mean_contribution != r.mean_contribution else f"{r.mean_contribution * 100:+.1f}"
        sh = "—" if r.share_raised_risk != r.share_raised_risk else f"{r.share_raised_risk:.0%}"
        L.append(f"| {r.group} | {r.direction} | {r.n:,} | {mc} | {sh} | {r.observed_new_help:.1%} |")
    if shap_df is not None:
        L += ["", "## Top 20 features by mean |SHAP| (tree component)", "", "| Feature | Mean abs SHAP |", "|---|---|"]
        for r in shap_df.head(20).itertuples():
            L.append(f"| {r.feature} | {r.mean_abs_shap:.4f} |")
    with open(os.path.join(out_dir, "report_expanded.md"), "w") as f:
        f.write("\n".join(L) + "\n")
